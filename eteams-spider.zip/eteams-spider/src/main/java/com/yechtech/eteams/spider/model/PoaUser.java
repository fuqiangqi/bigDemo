package com.yechtech.eteams.spider.model;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.util.Date;

/**
 * poa_user
 *
 * @author krx
 * @date 2022-07-13 14:04:19
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = false)
@TableName("poa_user")
public class PoaUser {
    @TableId(value = "id", type = IdType.AUTO)
    @JsonSerialize(using = ToStringSerializer.class)
    private Long id;
    private String userCode;
    private String deptCode;
    private String name;
    private String nickName;
    private String loginName;
    private String password;
    private String status;
    private Integer isAdmin;
    private String openId;
    private String avatar;
    private String province;
    private String city;
    private String district;
    private String addr;
    private String mobile;
    private Integer levelId;
    private String level;
    private BigDecimal levelCoefficient;
    private BigDecimal dailyShare;
    private BigDecimal averageDailySalary;
    private BigDecimal utilization;
    private BigDecimal targetUtilization;
    private Date entryTime;
    private Date quitTime;
    private Date probationEndDate;
    private Date internshipEndDate;
    private String type;
    private Integer isCheck;
    private Date modifyTime;
    private Integer modifyBy;
}
