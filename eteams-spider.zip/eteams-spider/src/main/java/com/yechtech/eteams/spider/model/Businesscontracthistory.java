package com.yechtech.eteams.spider.model;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.util.Date;

/**
 * businesscontracthistory
 *
 * @author krx
 * @date 2022-07-13 15:21:50
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = false)
@TableName("businesscontracthistory")
public class Businesscontracthistory {
    @TableId(value = "id", type = IdType.AUTO)
    @JsonSerialize(using = ToStringSerializer.class)
    private Long id;
    private String eteamscontractid;
    private String contractcode;
    private String contractname;
    private String manager;
    private String customer;
    private String contracttype;
    private String status;
    private BigDecimal totalamount;
    private Date begintime;
    private Date endtime;
    private String category;
    private String subcategory;
    private String eteamschanceid;
    private String eteamschancename;
    private BigDecimal percentdeliverycenter;
    private BigDecimal percentdevcenter;
    private BigDecimal percentsuccesscenter;
    private BigDecimal percentothercenter;
    private Date signedtime;
    private Boolean iscancle;
    private Boolean isdelete;
    private Date createtime;
    private Integer paymentday;
}
