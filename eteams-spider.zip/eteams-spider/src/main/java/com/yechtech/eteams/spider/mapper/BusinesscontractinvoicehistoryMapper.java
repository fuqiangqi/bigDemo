package com.yechtech.eteams.spider.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.yechtech.eteams.spider.model.Businesscontractinvoicehistory;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;
import java.util.Map;

/**
 * businesscontractinvoicehistory
 *
 * @author krx
 * @date 2022-07-13 16:05:21
 */
@Mapper
public interface BusinesscontractinvoicehistoryMapper extends BaseMapper<Businesscontractinvoicehistory> {
}
