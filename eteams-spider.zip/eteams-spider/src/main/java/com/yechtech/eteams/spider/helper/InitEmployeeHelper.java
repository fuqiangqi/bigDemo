package com.yechtech.eteams.spider.helper;

import cn.hutool.core.convert.Convert;
import cn.hutool.core.date.DateUtil;
import com.baomidou.mybatisplus.core.toolkit.StringPool;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.yechtech.eteams.spider.model.Businessemployee;
import com.yechtech.eteams.spider.model.PoaDept;
import com.yechtech.eteams.spider.model.PoaUser;
import com.yechtech.eteams.spider.service.IBusinessemployeeService;
import com.yechtech.eteams.spider.service.IPoaDeptService;
import com.yechtech.eteams.spider.service.IPoaUserService;
import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.WebDriver;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

@Component
@Slf4j
public class InitEmployeeHelper {
    @Resource
    IBusinessemployeeService businessemployeeService;
    @Resource
    IPoaDeptService poaDeptService;
    @Resource
    IPoaUserService poaUserService;

    public void execInitEmployee() {
        InitEmployee();
    }


    public void InitEmployee() {
        List<PoaDept> deptList = poaDeptService.list(Wrappers.<PoaDept>query().lambda().gt(PoaDept::getId, 0));
        businessemployeeService.remove(Wrappers.<Businessemployee>query().lambda().gt(Businessemployee::getId, 0));
        List<PoaUser> allList = poaUserService.list(Wrappers.<PoaUser>query().lambda().ne(PoaUser::getType, "systemAccount"));

        List<Businessemployee> empList = new ArrayList<>();
        for (PoaUser emp : allList) {
            if (emp.getStatus().equalsIgnoreCase("valid")) {
                Date begin = emp.getEntryTime();
                while (DateUtil.compare(begin, DateUtil.date(), "yyyy-MM-dd") < 0) {

                    Businessemployee his = new Businessemployee();
                    his.setMonthid(Convert.toInt(DateUtil.format(begin, "yyyyMM")));
                    his.setDateid(Convert.toInt(DateUtil.format(begin, "yyyyMMdd")));
                    his.setUsercode(emp.getUserCode());
                    his.setUsername(emp.getName());
                    Optional<PoaDept> first = deptList.stream().filter(x -> x.getDeptCode().equalsIgnoreCase(emp.getDeptCode())).findFirst();
                    his.setDeptname(first.isPresent() ? first.get().getDeptFullName() : StringPool.EMPTY);
                    his.setDeptcode(emp.getDeptCode());
                    his.setLevelcoefficient(emp.getLevelCoefficient());
                    his.setCreatetime(DateUtil.date());
                    his.setEmptype(emp.getType());
                    businessemployeeService.save(his);
                    begin = DateUtil.offsetDay(begin, 1);
                }
            } else if (emp.getStatus().equalsIgnoreCase("invalid")) {
                Date begin = emp.getEntryTime();
                while (DateUtil.compare(begin, DateUtil.date(), "yyyy-MM-dd") <= 0) {

                    Businessemployee his = new Businessemployee();
                    his.setMonthid(Convert.toInt(DateUtil.format(begin, "yyyyMM")));
                    his.setDateid(Convert.toInt(DateUtil.format(begin, "yyyyMMdd")));
                    his.setUsercode(emp.getUserCode());
                    his.setUsername(emp.getName());
                    Optional<PoaDept> first = deptList.stream().filter(x -> x.getDeptCode().equalsIgnoreCase(emp.getDeptCode())).findFirst();
                    his.setDeptname(first.isPresent() ? first.get().getDeptFullName() : StringPool.EMPTY);
                    his.setDeptcode(emp.getDeptCode());
                    his.setLevelcoefficient(emp.getLevelCoefficient());
                    his.setCreatetime(DateUtil.date());
                    his.setEmptype(emp.getType());
                    businessemployeeService.save(his);
                    begin = DateUtil.offsetDay(begin, 1);
                }
            }

        }

    }
}
