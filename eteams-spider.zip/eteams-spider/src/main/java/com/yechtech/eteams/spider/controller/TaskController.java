package com.yechtech.eteams.spider.controller;

import com.yechtech.eteams.spider.helper.TaskHelper;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

@RestController
public class TaskController {

    @Resource
    TaskHelper taskHelper;

    @GetMapping(value = "task")
    public void allTask() {
        taskHelper.task();
    }
}
