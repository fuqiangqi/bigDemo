package com.yechtech.eteams.spider.helper;

import cn.hutool.core.convert.Convert;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.thread.ThreadUtil;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.yechtech.eteams.spider.model.Businesscontract;
import com.yechtech.eteams.spider.model.Businesscontractreceive;
import com.yechtech.eteams.spider.service.IBusinesscontractService;
import com.yechtech.eteams.spider.service.IBusinesscontractreceiveService;
import com.yechtech.eteams.spider.service.IBusinesscontractreceivehistoryService;
import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;

@Component
@Slf4j
public class GetReceiveHelper {

    @Resource
    IBusinesscontractreceiveService businesscontractreceiveService;
    @Resource
    IBusinesscontractreceivehistoryService businesscontractreceivehistoryService;
    @Resource
    IBusinesscontractService businesscontractService;

    WebDriver webDriver;

    public void execGetReceive() {
        webDriver = LoginHelper.getWebDriver();
        GetReceive();
        LoginHelper.closeChromeDriver(webDriver);
    }

    public String execTaskGetReceive(WebDriver driver) {
        webDriver = driver;
        GetReceive();
        return null;
    }

    private void GetReceive() {
        //跳转回款

        webDriver.navigate().to("https://weapp.eteams.cn/crm/contract/9081908547940234461/ledger/list/receive");
        //webDriver.findElement(By.xpath("//*[@id='mCSB_2_container']/ul/li[1]/ul/li[6]/a")).Click();

        ThreadUtil.sleep(5000);

        //获取总页数

        WebElement totalPageNode = webDriver.findElement(By.cssSelector(".ui-pagination-total.ui-pagination-placeholder"));
        if (!totalPageNode.isDisplayed()) {
            Actions action = new Actions(webDriver);
            action.moveToElement(totalPageNode);
            action.perform();
        }

        int totalNum = Convert.toInt(totalPageNode.getText().replace("共", "").replace("条", ""));


        //在最后一页中获取最新的记录插入数据库
        //

        List<WebElement> receivelist = webDriver.findElements(By.xpath("//*[@id=\"modulePanel\"]/div/div/div/div/div[2]/div/div/div[3]/div/div/div[1]/table/tbody/tr"));
        for (WebElement invoice : receivelist) {
            String receiveId = invoice.getAttribute("data-id");
            List<WebElement> tds = invoice.findElements(By.tagName("td"));
            List<Businesscontractreceive> checkExit = businesscontractreceiveService.list(Wrappers.<Businesscontractreceive>query().lambda().eq(Businesscontractreceive::getReceiveid, receiveId));

            String contractname = tds.get(1).getText().trim().replace(" ", "");
            String etreamContractId = "";
            List<Businesscontract> contractList = businesscontractService.list(Wrappers.<Businesscontract>query().lambda().eq(Businesscontract::getContractname, contractname));
            if (contractList.size() == 1) {
                etreamContractId = contractList.get(0).getEteamscontractid();
            }

            if (checkExit.size() == 0) {
                Businesscontractreceive newreceive = new Businesscontractreceive();
                newreceive.setContractname(tds.get(1).getText().trim().replace(" ", ""));
                newreceive.setEteamscontractid(etreamContractId);
                newreceive.setReceiveid(receiveId);
                newreceive.setReceiveamount(Convert.toBigDecimal(tds.get(4).getText().replace(",", ""), null));

                newreceive.setReceivetime(DateUtil.parseTime(tds.get(5).getText()));
                newreceive.setCreatetime(DateUtil.date());
                newreceive.setUpdatetime(DateUtil.date());
                newreceive.setStagename(tds.get(3).getText().trim());
                businesscontractreceiveService.save(newreceive);
            } else {
                checkExit.get(0).setContractname(tds.get(1).getText().trim().replace(" ", ""));
                checkExit.get(0).setEteamscontractid(etreamContractId);
                checkExit.get(0).setReceiveamount(Convert.toBigDecimal(tds.get(4).getText().replace(",", ""), null));
                checkExit.get(0).setReceivetime(DateUtil.parseTime(tds.get(5).getText()));
                checkExit.get(0).setCreatetime(DateUtil.date());
                checkExit.get(0).setUpdatetime(DateUtil.date());
                checkExit.get(0).setStagename(tds.get(3).getText().trim());
                businesscontractreceiveService.updateById(checkExit.get(0));
            }

        }


        //获取点击下一页的次数
        int clickNextTime = totalNum / 30;

        for (int i = 0; i <= clickNextTime; i++) {
            WebElement nextNode = webDriver.findElement(By.cssSelector(".ui-pagination-pager-item.ui-pagination-pager-next"));
            if (!nextNode.isDisplayed()) {
                Actions action = new Actions(webDriver);
                action.moveToElement(nextNode);
                nextNode.click();
                action.perform();
            }

            JavascriptExecutor javaScriptExecutor = (JavascriptExecutor) webDriver;
            javaScriptExecutor.executeScript("arguments[0].click();", nextNode);
            ThreadUtil.sleep(2000);

            receivelist = webDriver.findElements(By.xpath("//*[@id=\"modulePanel\"]/div/div/div/div/div[2]/div/div/div[3]/div/div/div[1]/table/tbody/tr"));

            for (WebElement invoice : receivelist) {
                String receiveId = invoice.getAttribute("data-id");
                List<WebElement> tds = invoice.findElements(By.tagName("td"));
                List<Businesscontractreceive> checkExit = businesscontractreceiveService.list(Wrappers.<Businesscontractreceive>query().lambda().eq(Businesscontractreceive::getReceiveid, receiveId));


                String contractname = tds.get(1).getText().trim().replace(" ", "");
                String etreamContractId = "";
                List<Businesscontract> contractList = businesscontractService.list(Wrappers.<Businesscontract>query().lambda().eq(Businesscontract::getContractname, contractname));
                if (contractList.size() == 1) {
                    etreamContractId = contractList.get(0).getEteamscontractid();
                }

                if (checkExit.size() == 0) {
                    Businesscontractreceive newreceive = new Businesscontractreceive();
                    newreceive.setContractname(tds.get(1).getText().trim().replace(" ", ""));
                    newreceive.setEteamscontractid(etreamContractId);
                    newreceive.setReceiveid(receiveId);
                    newreceive.setReceiveamount(Convert.toBigDecimal(tds.get(4).getText().replace(",", ""), null));

                    newreceive.setReceivetime(DateUtil.parseTime(tds.get(5).getText()));
                    newreceive.setCreatetime(DateUtil.date());
                    newreceive.setUpdatetime(DateUtil.date());
                    newreceive.setStagename(tds.get(3).getText().trim());
                    businesscontractreceiveService.save(newreceive);
                } else {
                    checkExit.get(0).setContractname(tds.get(1).getText().trim().replace(" ", ""));
                    checkExit.get(0).setEteamscontractid(etreamContractId);
                    checkExit.get(0).setReceiveamount(Convert.toBigDecimal(tds.get(4).getText().replace(",", ""), null));
                    checkExit.get(0).setReceivetime(DateUtil.parseTime(tds.get(5).getText()));
                    checkExit.get(0).setCreatetime(DateUtil.date());
                    checkExit.get(0).setUpdatetime(DateUtil.date());
                    checkExit.get(0).setStagename(tds.get(3).getText().trim());
                    businesscontractreceiveService.updateById(checkExit.get(0));
                }

            }

        }


        //var allReceive = receiveHelper.FindList(x => x.Id > 0);


        //foreach (var receive in allReceive)
        //{
        //    var url = string.Format("https://www.eteams.cn/crms/contractLedgerSetting?menu=key_contractReceiveLedger|state_0|module_contract|targetId_&search=view_&table=view_&info=view_ContractReceiveView|receiveId_{0}&tab=type_contractReceiveLedger", receive.ReceiveID);

        //    // url = "https://www.eteams.cn/crms/contract?menu=key_all|state_0|module_contract|targetId_506&search=view_&table=view_&info=view_ContractView|contractId_8472303386626503805&tab=type_";
        //    try
        //    {

        //        webDriver.Navigate().GoToUrl(url);

        //        ThreadUtil.sleep(3000);


        //        var contractNode = webDriver.findElement(By.cssSelector(".entity-item.js_contractName.j_showContract")).findElement(By.tagName("a"));
        //        var contractName = contractNode.getText();
        //        var contractID = contractNode.getAttribute("data-id");


        //        var stageNode = webDriver.findElement(By.cssSelector(".entity-item.js_contractStageName")).findElement(By.tagName("a"));
        //        var stageName = stageNode.getText();
        //        var stageID = stageNode.getAttribute("data-id");


        //        var receiveAmount = webDriver.findElement(By.cssSelector(".form-control.js_field.js_receive_money.textinput")).getAttribute("value");//

        //        var receiveTime = webDriver.findElement(By.Id("receiveTime")).getAttribute("value");//


        //        receive.ContractName = contractName;
        //        receive.EteamsContractID = contractID;

        //        receive.EteamsContractStageID = stageID;
        //        receive.StageName = stageName;


        //        if (!string.IsNullOrEmpty(receiveAmount))
        //        {
        //            receive.ReceiveAmount = Decimal.Parse(receiveAmount);
        //        }


        //        if (!string.IsNullOrEmpty(receiveTime))
        //        {
        //            receive.ReceiveTime = DateTime.Parse(receiveTime);
        //        }

        //        receive.updatetime = DateTime.Now;

        //        receiveHelper.Update(receive);

        //        businesscontractreceivehistory his = new businesscontractreceivehistory();
        //        his.EteamsContractID = receive.EteamsContractID;
        //        his.ContractName = receive.ContractName;
        //        his.createtime = receive.updatetime;
        //        his.EteamsContractStageID = receive.EteamsContractStageID;
        //        his.StageName = receive.StageName;

        //        his.ReceiveTime = receive.ReceiveTime;
        //        his.ReceiveAmount = receive.ReceiveAmount;

        //        receivehistoryHelper.Add(his);


        //        Logger.Log("Receive SUCCESS:" + url);

        //    }
        //    catch (Exception ex)
        //    {

        //        receive.IsDelete = true;
        //        receive.updatetime = DateTime.Now;
        //        receiveHelper.Update(receive);


        //        var msg = "Receive Failure:" + url;
        //        Logger.Log(msg);

        //        stringBuilder.Append(msg);
        //        Logger.Log(ex);

        //    }


        //}
    }
}
