package com.yechtech.eteams.spider.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.yechtech.eteams.spider.model.Businessproject;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;
import java.util.Map;

/**
 * businessproject
 *
 * @author krx
 * @date 2022-07-13 14:04:19
 */
@Mapper
public interface BusinessprojectMapper extends BaseMapper<Businessproject> {

}
