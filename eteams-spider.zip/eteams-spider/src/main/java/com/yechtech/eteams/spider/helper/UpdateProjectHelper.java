package com.yechtech.eteams.spider.helper;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.convert.Convert;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.exceptions.ExceptionUtil;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.yechtech.eteams.spider.model.Businessproject;
import com.yechtech.eteams.spider.model.PoaProject;
import com.yechtech.eteams.spider.service.IBusinessprojectService;
import com.yechtech.eteams.spider.service.IPoaProjectService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;

@Component
@Slf4j
public class UpdateProjectHelper {
    @Resource
    IBusinessprojectService businessprojectService;
    @Resource
    IPoaProjectService poaProjectService;

    public void execUpdateProject() {
        UpdateProject();
    }

    private void UpdateProject() {
        try {

            int dateid = Convert.toInt(DateUtil.format(DateUtil.date(), "yyyyMMdd"));
            businessprojectService.remove(Wrappers.<Businessproject>query().lambda().eq(Businessproject::getDateid, dateid));

            List<PoaProject> allList = poaProjectService.list(Wrappers.<PoaProject>query().lambda().ne(PoaProject::getStage, "商务关闭").and(v -> v.ne(PoaProject::getIsDeleted, "0")));


            for (PoaProject project : allList) {

                Businessproject his = BeanUtil.copyProperties(project, Businessproject.class);
                his.setMonthid(Convert.toInt(DateUtil.format(DateUtil.date(), "yyyyMM")));
                his.setDateid(Convert.toInt(DateUtil.format(DateUtil.date(), "yyyyMMdd")));
                businessprojectService.save(his);
            }
        } catch (Exception e) {
            log.error("更新项目信息失败" + ExceptionUtil.stacktraceToOneLineString(e));
            
        }

    }
}
