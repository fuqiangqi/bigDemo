package com.yechtech.eteams.spider.helper;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.convert.Convert;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.exceptions.ExceptionUtil;
import cn.hutool.core.thread.ThreadUtil;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.yechtech.eteams.spider.model.*;
import com.yechtech.eteams.spider.service.*;
import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;


/**
 * 合同信息
 *
 * @auth krx
 * @date 2022/7/13 15:07
 */
@Component
@Slf4j
public class ContractNewHelper {
    @Resource
    IBusinesscontractService businesscontractService;
    @Resource
    IBusinesscontractandchanceService businesscontractandchanceService;
    @Resource
    IBusinesscontractandchancehisService businesscontractandchancehisService;
    @Resource
    IBusinesscontractstagehistoryService businesscontractstagehistoryService;
    @Resource
    IBusinesscontractstageService businesscontractstageService;
    @Resource
    IBusinesscontracthistoryService businesscontracthistoryService;


    WebDriver webDriver;

    StringBuilder stringBuilder = new StringBuilder();


    public void execContractNew() {
        webDriver = LoginHelper.getWebDriver();
        GetContractNew();
        LoginHelper.closeChromeDriver(webDriver);
    }

    public String execTaskContractNew(WebDriver driver) {
        webDriver = driver;
        GetContractNew();
        return stringBuilder.toString();
    }

    private void GetContractNew() {
        boolean autorun = true;
        log.info("开始获取合同内信息");
        //跳转到我的全部合同
        webDriver.navigate().to("https://weapp.eteams.cn/crm/contract/9081908547940234461/list/all");
        //webDriver.findElement(By.xpath("//*[@id='mCSB_2_container']/ul/li[1]/ul/li[6]/a")).click();

        ThreadUtil.sleep(5000);


        //获取总页数
        WebElement totalPageNode = webDriver.findElement(By.cssSelector(".ui-pagination-total.ui-pagination-placeholder"));
        if (!totalPageNode.isDisplayed()) {
            Actions action = new Actions(webDriver);
            action.moveToElement(totalPageNode);
            action.perform();
        }

        int totalNum = Convert.toInt(totalPageNode.getText().replace("共", "").replace("条", ""));
        if (autorun) {
            List<WebElement> cntractlist = webDriver.findElements(By.xpath("//*[@id=\"modulePanel\"]/div/div/div/div/div[2]/div/div/div[3]/div/div/div/div[1]/div[1]/table/tbody/tr"));

            for (WebElement cntract : cntractlist) {
                List<WebElement> tds = cntract.findElements(By.tagName("td"));
                String contractname = tds.get(1).getText().trim();

                String contractid = cntract.getAttribute("data-id");
                List<Businesscontract> checkExit = businesscontractService.list(Wrappers.<Businesscontract>query().lambda().eq(Businesscontract::getEteamscontractid, contractid));
                if (checkExit.size() == 0) {
                    Businesscontract newbusinesscontract = new Businesscontract();
                    newbusinesscontract.setEteamscontractid(contractid);
                    newbusinesscontract.setCreatetime(DateUtil.date());
                    newbusinesscontract.setContractname(contractname.replace(" ", ""));
                    businesscontractService.save(newbusinesscontract);
                } else {
                    checkExit.get(0).setUpdatetime(DateUtil.date());
                    checkExit.get(0).setContractname(contractname.replace(" ", ""));
                    businesscontractService.saveOrUpdate(checkExit.get(0));
                }

            }

            ThreadUtil.sleep(3000);

            //获取点击下一页的次数
            int clickNextTime = totalNum / 30;

            for (int i = 0; i <= clickNextTime; i++) {
                WebElement nextNode = webDriver.findElement(By.cssSelector(".ui-pagination-pager-item.ui-pagination-pager-next"));
                if (!nextNode.isDisplayed()) {
                    Actions action = new Actions(webDriver);
                    action.moveToElement(nextNode);
                    nextNode.click();
                    action.perform();
                }


                JavascriptExecutor javaScriptExecutor = (JavascriptExecutor) webDriver;
                javaScriptExecutor.executeScript("arguments[0].click();", nextNode);

                ThreadUtil.sleep(6000);


                cntractlist = webDriver.findElements(By.xpath("//*[@id=\"modulePanel\"]/div/div/div/div/div[2]/div/div/div[3]/div/div/div/div[1]/table/tbody/tr"));
                for (WebElement cntract : cntractlist) {
                    String contractid = cntract.getAttribute("data-id");
                    List<WebElement> tds = cntract.findElements(By.tagName("td"));
                    String contractname = tds.get(1).getText().trim();

                    List<Businesscontract> checkExit = businesscontractService.list(Wrappers.<Businesscontract>query().lambda().eq(Businesscontract::getEteamscontractid, contractid));
                    if (checkExit.size() == 0) {
                        Businesscontract newbusinesscontract = new Businesscontract();
                        newbusinesscontract.setEteamscontractid(contractid);
                        newbusinesscontract.setCreatetime(DateUtil.date());
                        newbusinesscontract.setContractname(contractname.replace(" ", ""));
                        businesscontractService.save(newbusinesscontract);
                    } else {
                        checkExit.get(0).setUpdatetime(DateUtil.date());
                        checkExit.get(0).setContractname(contractname.replace(" ", ""));
                        businesscontractService.updateById(checkExit.get(0));
                    }
                }

                ThreadUtil.sleep(3000);
            }

        }


        List<Businesscontract> contractList = businesscontractService.list(Wrappers.<Businesscontract>query().lambda().gt(Businesscontract::getId, 0));
        for (Businesscontract contract : contractList) {
//            if (!"8472303386626503803".equals(contract.getEteamscontractid())) {
//                continue;
//            }
            String url = String.format("https://weapp.eteams.cn/crm/contract/9081908547940234461/list/all/contractViewPage/%s", contract.getEteamscontractid());
            log.info("开始获取合同详细信息" + url);

            //url = "https://www.eteams.cn/crms/contract?menu=key_all|state_0|module_contract|targetId_506&search=view_&table=view_&info=view_ContractView|contractId_8472303386626503805&tab=type_";
            try {

                webDriver.navigate().to(url);
                ThreadUtil.sleep(3000);
                GetContractDetail(contract, url);
            } catch (Exception ex) {
                try {
                    webDriver.navigate().refresh();
                    ThreadUtil.sleep(5000);
                    GetContractDetail(contract, url);
                } catch (Exception ex2) {
                    String msg = "Get contract Failure:" + url;
                    log.info(msg);
                    stringBuilder.append(msg);
                    log.error(ExceptionUtil.stacktraceToOneLineString(ex2));

                }

            }

            log.info("结束获取合同详细信息" + url);


        }
    }

    private void GetContractDetail(Businesscontract contract, String url) {
        boolean isCancle = false;

        boolean isDelete = false;

//        try {
//            //判断是不是被作废和逻辑删除
//            String displaytext = webDriver.findElement(By.cssSelector(".clue-eui-gapbar-span.ml-70")).getText();
//            if (displaytext.equals("此合同已作废")) {
//                isCancle = true;
//            } else if (displaytext.equals("此合同已被移到回收站")) {
//                isDelete = true;
//            }
//        } catch (Exception ex2) {
//            log.error(ExceptionUtil.stacktraceToOneLineString(ex2));
//        }

//        try {
//
//            if (!isCancle && !isDelete) {
//                //判断是不是被删除
//                String deletetext = webDriver.findElement(By.cssSelector(".alert-heading")).getText();
//                if (deletetext.equals("对不起! 你访问的数据服务器不存在")) {
//                    isDelete = true;
//                }
//            }
//        } catch (Exception ex2) {
//            log.error(ExceptionUtil.stacktraceToOneLineString(ex2));
//        }


        //判断是不是被删除
        String dialogid = "";
        String contentdiv = "div[2]/div/div/div/div[2]/div/div/div/div/div/div/div/div[1]";
        String stagediv = "div[2]/div/div/div/div[2]/div/div/div/div/div/div/div/div[2]";

        if (!isCancle && !isDelete) {
            dialogid = webDriver.findElement(By.cssSelector(".ui-dialog-wrap.ui-dialog-wrap-right.ui-dialog-content-scale")).getAttribute("id");


            List<WebElement> tempInfos = webDriver.findElements(By.cssSelector(".crm_contractApprover_spanInfo.js_approverInfo"));
            if (tempInfos.size() > 0) {
                contentdiv = "div[2]/div/div/div/div[2]/div/div/div/div/div/div/div/div[2]";
                stagediv = "div[2]/div/div/div/div[2]/div/div/div/div/div/div/div/div[3]";
            }


            //合同编号
            String contractCode = webDriver.findElement(By.xpath("//*[@id=\"widget_8752165214771160849\"]/div[2]/div[2]/input")).getAttribute("value");
            //名称
            String contractname = webDriver.findElement(By.xpath("//*[@id=\"" + dialogid + "\"]/" + contentdiv + "/div[1]/div/div[2]/input")).getAttribute("value").replace(" ", "");
            //负责人
            String managerName = webDriver.findElement(By.xpath("//*[@id=\"" + dialogid + "\"]/" + contentdiv + "/div[2]/div/div[2]/div/div[2]/div/div/div/div/div/div/div/div/div/div/div/div/div/span")).getText();
            //所属客户
            String customerName = webDriver.findElement(By.xpath("//*[@id=\"" + dialogid + "\"]/" + contentdiv + "/div[2]/div/div[2]/div/div[2]/div/div/div/div/div/div/div/div/div/div/div/div/div/span")).getText();
            //类型
            String contractType = webDriver.findElement(By.xpath("//*[@id=\"" + dialogid + "\"]/div[2]/div/div/div/div[2]/div/div/div/div/div/div/div/div[1]/div[3]/div[1]/div[1]/div/div[2]/div/div/div[1]/span/div/div/div/span[1]/div/div/div/div/div/div/div/div/div/div/div/span")).getText();
            //金额
            String money = webDriver.findElement(By.id("totalMoney")).getAttribute("value").replace(",", "");
            //状态
            String status = webDriver.findElement(By.xpath("//*[@id=\"" + dialogid + "\"]/div[2]/div/div/div/div[2]/div/div/div/div/div/div/div/div[1]/div[3]/div[2]/div[1]/div/div[2]/div/div/div[1]/span/div/div/div/span[1]/div/div/div/div/div/div/div/div/div/div/div/span")).getText();
            //***开始时间
            String begintime = webDriver.findElement(By.xpath("//*[@id=\"" + dialogid + "\"]/div[2]/div/div/div/div[2]/div/div/div/div/div/div/div/div[1]/div[3]/div[2]/div[2]/div/div[2]/div/div/div/div/div/input")).getAttribute("value");
            //***结束时间
            String endtime = webDriver.findElement(By.xpath("//*[@id=\"" + dialogid + "\"]/div[2]/div/div/div/div[2]/div/div/div/div/div/div/div/div[1]/div[3]/div[3]/div/div/div[2]/div/div/div/div/div/input")).getAttribute("value");
            //大类
            String category = webDriver.findElement(By.xpath("//*[@id=\"widget_7962383096624829980\"]/div[2]/div[2]/div/div/div/span[1]")).getText();
            //小类
            String subcategory = webDriver.findElement(By.xpath("//*[@id=\"widget_7962667962516579439\"]/div[2]/div[2]/div/div/div/span[1]")).getText();
            //签约时间
            String signtime = webDriver.findElement(By.xpath("//*[@id=\"" + dialogid + "\"]/div[2]/div/div/div/div[2]/div/div/div/div/div/div/div/div[1]/div[3]/div[6]/div/div/div[2]/div/div/div[1]/div/div/input")).getAttribute("value");
            //付款账期
            String paymentday = webDriver.findElement(By.xpath("//*[@id=\"widget_4742995096437444553\"]/div[2]/div[2]/input")).getAttribute("value");
            ////关联商机
            //var chanceid = string.Empty;
            //var chanceName = string.Empty;
            try {
                //var chanceNode = webDriver.findElement(By.xpath("//div[@class='js_relateitem_container relevance-card j_relevance-card j_item-container']/span/a[1]"));
                //chanceid = chanceNode.getAttribute("data-id");
                //chanceName = chanceNode.getText();

//                List<WebElement> chanceNodes = webDriver.findElements(By.xpath("//*[@id=\"widget_8752165214771160848\"]/div[2]/div[2]/div/div/div/div/div/div/div/div/div/div"));
                List<WebElement> chanceNodes = webDriver.findElements(By.xpath("//*[@id=\"widget_8752165214771160848\"]/div[2]/div[2]/div/div/div/div/div"));
                businesscontractandchanceService.del(contract.getEteamscontractid());
                for (WebElement chanceNode : chanceNodes) {

                    String chanceid = chanceNode.getAttribute("data-id");
                    String chanceName = chanceNode.getText();

                    Businesscontractandchance newbcc = new Businesscontractandchance();
                    newbcc.setEteamschanceid(chanceid);
                    newbcc.setEteamscontractid(contract.getEteamscontractid());
                    newbcc.setCreatetime(DateUtil.date());
                    businesscontractandchanceService.save(newbcc);

                    Businesscontractandchancehis newbcch = new Businesscontractandchancehis();
                    newbcch.setEteamschanceid(chanceid);
                    newbcch.setEteamscontractid(contract.getEteamscontractid());
                    newbcch.setUpdatetime(DateUtil.date());
                    businesscontractandchancehisService.save(newbcch);
                }

            } catch (Exception ex) {
                log.error(ExceptionUtil.stacktraceToOneLineString(ex));
            }

            String percentDeliveryCenter = webDriver.findElement(By.xpath("//*[@id=\"widget_4742684331421555065\"]/div[2]/div[2]/div/input")).getAttribute("value");
            String percentDevCenter = webDriver.findElement(By.xpath("//*[@id=\"widget_4742684331421555067\"]/div[2]/div[2]/div/input")).getAttribute("value");
            String percentSuccessCenter = webDriver.findElement(By.xpath("//*[@id=\"widget_3505054487106790509\"]/div[2]/div[2]/div/input")).getAttribute("value");
            String percentOtherCenter = webDriver.findElement(By.xpath("//*[@id=\"widget_4742684331421555068\"]/div[2]/div[2]/div/input")).getAttribute("value");
            //--封装对象
            contract.setCustomer(customerName);
            contract.setManager(managerName);
            contract.setContracttype(contractType);
            contract.setTotalamount(StringUtils.hasLength(money) && StringUtils.hasText(money) ? Convert.toBigDecimal(money, BigDecimal.ZERO) : null);
            contract.setStatus(status);
            contract.setBegintime(StringUtils.hasLength(begintime) && StringUtils.hasText(begintime) ? DateUtil.parse(begintime, "yyyy-MM-dd") : null);
            contract.setEndtime(StringUtils.hasLength(endtime) && StringUtils.hasText(endtime) ? DateUtil.parse(endtime, "yyyy-MM-dd") : null);
            contract.setPaymentday(StringUtils.hasLength(paymentday) && StringUtils.hasText(paymentday) ? Convert.toInt(paymentday) : null);
            contract.setCategory(category);
            contract.setSubcategory(subcategory);
            contract.setContractcode(contractCode);
            contract.setPercentdeliverycenter(StringUtils.hasLength(percentDeliveryCenter) && StringUtils.hasText(percentDeliveryCenter) ? Convert.toBigDecimal(percentDeliveryCenter, BigDecimal.ZERO) : null);
            contract.setPercentdevcenter(StringUtils.hasLength(percentDevCenter) && StringUtils.hasText(percentDevCenter) ? Convert.toBigDecimal(percentDevCenter, BigDecimal.ZERO) : null);
            contract.setPercentothercenter(StringUtils.hasLength(percentOtherCenter) && StringUtils.hasText(percentOtherCenter) ? Convert.toBigDecimal(percentOtherCenter, BigDecimal.ZERO) : null);
            contract.setPercentsuccesscenter(StringUtils.hasLength(percentSuccessCenter) && StringUtils.hasText(percentSuccessCenter) ? Convert.toBigDecimal(percentSuccessCenter, BigDecimal.ZERO) : null);
            contract.setSignedtime(StringUtils.hasLength(signtime) && StringUtils.hasText(signtime) ? DateUtil.parse(signtime, "yyyy-MM-dd") : null);
            //contract.EteamsChanceId = chanceid;
            //contract.EteamsChanceName = chanceName;
        } else {
            contract.setIscancle(isCancle);
            contract.setIsdelete(isDelete);
        }


        contract.setUpdatetime(DateUtil.date());
        businesscontractService.updateById(contract);

        //插入历史记录

        Businesscontracthistory businesscontracthistory = BeanUtil.copyProperties(contract, Businesscontracthistory.class);
        businesscontracthistory.setId(null);
        businesscontracthistoryService.save(businesscontracthistory);

        if (!isCancle && !isDelete) {
            //删除所有批次号
            businesscontractstageService.del(contract.getEteamscontractid());
            //获取付款批次
            //定位关联事件
            //ui-icon ui-icon-wrapper  ui-card-detail-form-tags-footer-icon-hide
//            WebElement linkeventmark = webDriver.findElement(By.cssSelector(".ui-card-detail-form-tags-footer.ui-card-detail-form-tags-footer-hidden"));
//            if (!linkeventmark.isSelected()) {
//                Actions action = new Actions(webDriver);
//                action.moveToElement(linkeventmark);
//                action.click();
//                action.perform();
//            }
            List<WebElement> stageDivList = webDriver.findElements(By.xpath("//*[@id=\"stage\"]/div"));
            if (stageDivList.size() > 0) {
                for (WebElement stageDiv : stageDivList) {
                    try {
                        if (!stageDiv.isSelected()) {
                            Actions action = new Actions(webDriver);
                            action.moveToElement(stageDiv);
                            action.click();
                            action.perform();
                            ThreadUtil.sleep(500);
                        }

                        List<WebElement> stageSpanList = webDriver.findElements(By.cssSelector(".weapp-crm-card-period-periodItem"));
                        List<Businesscontractstage> stages = new ArrayList<>();
                        List<Businesscontractstagehistory> stagehistorys = new ArrayList<>();
                        int index = 1;
                        for (int i = 0; i < stageSpanList.size(); i++) {
                            String stageName = webDriver.findElement(By.xpath("//*[@id=\"" + dialogid + "\"]/div[2]/div/div/div/div[2]/div/div/div/div/div/div/div/div[2]/div/div["+index+"]/div[1]/span[1]")).getText();
                            String targettime = webDriver.findElement(By.xpath("//*[@id=\"" + dialogid + "\"]/div[2]/div/div/div/div[2]/div/div/div/div/div/div/div/div[2]/div/div["+index+"]/div[2]/span[2]")).getText().replace("计划时间", "").replace(" ", "");
                            String stageAmount = webDriver.findElement(By.xpath("//*[@id=\"" + dialogid + "\"]/div[2]/div/div/div/div[2]/div/div/div/div/div/div/div/div[2]/div/div["+index+"]/div[2]/span[4]")).getText().replace("已回款", "").replace("元", "").replace(" ", "").replace(",", "");

                            Businesscontractstage stage = new Businesscontractstage();
                            stage.setContractname(contract.getContractname());
                            stage.setEteamscontractid(contract.getEteamscontractid());
                            stage.setStagename(stageName);
                            stage.setStageamount(StringUtils.hasLength(stageAmount) && StringUtils.hasText(stageAmount) ? Convert.toBigDecimal(stageAmount) : null);
                            stage.setTargettime(StringUtils.hasLength(targettime) && StringUtils.hasText(targettime) ? DateUtil.parse(targettime, "yyyy-MM-dd") : null);
                            stage.setCreatetime(DateUtil.date());
                            stage.setUpdatetime(stage.getCreatetime());
                            stages.add(stage);

                            Businesscontractstagehistory stagehistory = new Businesscontractstagehistory();
                            stagehistory.setContractname(contract.getContractname());
                            stagehistory.setEteamscontractid(contract.getEteamscontractid());
                            stagehistory.setStagename(stage.getStagename());

                            stagehistory.setEteamscontractstageid(stage.getEteamscontractstageid());
                            stagehistory.setStageamount(stage.getStageamount());
                            stagehistory.setTargettime(stage.getTargettime());
                            stagehistory.setCreatetime(stage.getCreatetime());
                            stagehistorys.add(stagehistory);
                            index++;
                        }

//                        stage.setEteamscontractstageid(stageId);
                        businesscontractstageService.saveBatch(stages);
                        businesscontractstagehistoryService.saveBatch(stagehistorys);
                    } catch (Exception ex) {
                        log.info("获取期次失败" + url);
                    }

                }
            }
        }

        log.info("SUCCESS:" + url);
    }
}
