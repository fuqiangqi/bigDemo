using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using Yechtech.DataCollecter.Entity;
using Yechtech.Utility;

namespace Yechtech.DataCollecter
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }


        ChromedriverHelper processHelper;
        IWebDriver webDriver;



        private void Login()
        {
            processHelper =  new ChromedriverHelper();
            ChromeOptions options = new ChromeOptions();
            webDriver = new ChromeDriver(options);
            webDriver.Manage().Window.Maximize();

            //跳至登陆
            webDriver.Navigate().GoToUrl("https://passport.eteams.cn/login");
     

            ClickLogin();

            //System.Threading.Thread.Sleep(15000);
        }

        private void ClickLogin()
        {
            while(true)
            {

                //////*[@id="root"]/div/div[2]/div/div/div[6]/button
                try
                {
                    //找到页面上的搜索框 输入关键字
                    Thread.Sleep(2000);
                    /*webDriver.FindElement(By.XPath("//*[@id='root']/div/div[2]/div/div/div[4]/div[1]/input")).SendKeys("17717936101");
                 webDriver.FindElement(By.XPath("//*[@id='root']/div/div[2]/div/div/div[4]/div[2]/input")).SendKeys("226697");*/
                    webDriver.FindElement(By.XPath("//*[@id='root']/div/div/div/div[2]/div/div/div/div/div[4]/div[1]/input")).SendKeys("17717936101");
                    webDriver.FindElement(By.XPath("//*[@id='root']/div/div/div/div[2]/div/div/div/div/div[4]/div[2]/input")).SendKeys("226697");
                    System.Threading.Thread.Sleep(5000);
                    //点击搜索按钮
                    webDriver.FindElement(By.XPath("//*[@id='root']/div/div/div/div[2]/div/div/div/div/div[6]/button")).Click();
                    System.Threading.Thread.Sleep(6000);
                }
                catch
                {
                    break;
                }
            }
        }


        private void button1_Click(object sender, EventArgs e)
        {
           

            Login();
            //GetChance();
            GetChanceNew();
            CloseProcess();

        }

        private void CloseProcess()
        {
            webDriver.Close();

            processHelper.CloseChromeDriver(webDriver);
        }

        private void GetChanceNew()
        {

            //跳转到我的全部商机
            webDriver.Navigate().GoToUrl("https://weapp.eteams.cn/crm/salechance/9081908547940234461/list/all");
            //webDriver.FindElement(By.XPath("//*[@id='mCSB_2_container']/ul/li[1]/ul/li[6]/a")).Click();

            System.Threading.Thread.Sleep(6000);

            DBHelper<businesschance> businesschanceHelper = new DBHelper<businesschance>();

            if (autorun)
            {
                //点击包含赢单、输单和无效
                var includesucess = webDriver.FindElement(By.CssSelector(".ui-checkbox-left"));

                includesucess.Click();
                System.Threading.Thread.Sleep(3000);

                //获取总页数

                var totalPageNode = webDriver.FindElement(By.CssSelector(".ui-pagination-total.ui-pagination-placeholder"));
                if (!totalPageNode.Displayed)
                {
                    Actions action = new Actions(webDriver);
                    action.MoveToElement(totalPageNode);
                    action.Perform();
                }

                var totalNum = Int32.Parse(totalPageNode.Text.Replace("共", "").Replace("条", ""));




                var chancelist = webDriver.FindElements(By.XPath("//*[@id=\"modulePanel\"]/div/div/div/div[1]/div[2]/div/div/div[2]/div/div/div/div/div[1]/div[1]/table/tbody/tr"));

                bool morePage = true;


           

                foreach (var chance in chancelist)
                {

                    var chanceid = chance.GetAttribute("data-id");

                    if (!chance.Displayed)
                    {
                        Actions action2 = new Actions(webDriver);
                        action2.MoveToElement(chance);
                        action2.Perform();
                        System.Threading.Thread.Sleep(1000);
                    }



                    var checkExit = businesschanceHelper.FindList(x => x.EteamsId == chanceid);
                    if (checkExit.Count == 0)
                    {
                        businesschance newbusinesschance = new businesschance();
                        newbusinesschance.EteamsId = chanceid;
                        var createtimeNode = chance.FindElements(By.TagName("td"))[10];
                        newbusinesschance.CreateTime = DateTime.Parse(createtimeNode.Text);
                        var updateNode = chance.FindElements(By.TagName("td"))[5];
                        DateTime updatetime = DateTime.Parse(updateNode.Text);
                        newbusinesschance.UpdateTime = updatetime;
                        businesschanceHelper.Add(newbusinesschance);
                    }
                    else
                    {
                        checkExit[0].EteamsId = chanceid;
                        var createtimeNode = chance.FindElements(By.TagName("td"))[10];
                        
                        
                        checkExit[0].CreateTime = DateTime.Parse(createtimeNode.Text);
                        var updateNode = chance.FindElements(By.TagName("td"))[5];
                        DateTime updatetime = DateTime.Parse(updateNode.Text);
                        checkExit[0].UpdateTime = updatetime;

                    
                        //if ((updatetime - DateTime.Parse(DateTime.Now.AddDays(-3).ToString("yyyy-MM-dd"))).Days > 0)
                        //{ 

                        //    Logger.Log(updateNode.Text);
                        //    morePage = false;
                        //    break;
                        //}

                        businesschanceHelper.Update(checkExit[0]);
                    }

                }


               
                    //获取点击下一页的次数
                    int clickNextTime = totalNum / 30;


                for (int i = 0; i <= clickNextTime; i++)
                {
                    if (!morePage)
                    {
                        break;
                    }
                    var nextNode = webDriver.FindElement(By.CssSelector(".ui-icon-xs.ui-icon-svg.Icon-Right-arrow01"));
                    nextNode.Click();
                    System.Threading.Thread.Sleep(1000);

                    chancelist = webDriver.FindElements(By.XPath("//*[@id=\"modulePanel\"]/div/div/div/div[1]/div[2]/div/div/div[2]/div/div/div/div/div[1]/table/tbody/tr"));

                    System.Threading.Thread.Sleep(3000);

                    foreach (var chance in chancelist)
                    {
                        try
                        {
                            var chanceid = chance.GetAttribute("data-id");

                            if (!chance.Displayed)
                            {
                                Actions action2 = new Actions(webDriver);
                                action2.MoveToElement(chance);
                                action2.Perform();
                                System.Threading.Thread.Sleep(1000);
                            }



                            var checkExit = businesschanceHelper.FindList(x => x.EteamsId == chanceid);
                            if (checkExit.Count == 0)
                            {
                                businesschance newbusinesschance = new businesschance();
                                newbusinesschance.EteamsId = chanceid;
                                var createtimeNode = chance.FindElements(By.TagName("td"))[10];
                                newbusinesschance.CreateTime = DateTime.Parse(createtimeNode.Text);
                                var updateNode = chance.FindElements(By.TagName("td"))[5];
                                DateTime updatetime = DateTime.Parse(updateNode.Text);
                                newbusinesschance.UpdateTime = DateTime.Now;
                                businesschanceHelper.Add(newbusinesschance);
                            }
                            else
                            {
                                checkExit[0].EteamsId = chanceid;
                                var createtimeNode = chance.FindElements(By.TagName("td"))[10];

                                checkExit[0].CreateTime = DateTime.Parse(createtimeNode.Text);

                                var updateNode = chance.FindElements(By.TagName("td"))[5];
                                DateTime updatetime = DateTime.Now;
                                checkExit[0].UpdateTime = updatetime;


                                //if ((updatetime - DateTime.Parse(DateTime.Now.AddDays(-3).ToString("yyyy-MM-dd"))).Days > 0)
                                //{
                                //    morePage = false;
                                //    Logger.Log(updateNode.Text);
                                //    break;
                                //}

                                businesschanceHelper.Update(checkExit[0]);
                            }
                        }
                        catch (Exception d)
                        {
                            int l = 0;
                        }


                    }


                }
              

               

            }










            //开始打开页面遍历商机内容
            ////负责人js_managerName
            //chanceUrlList.Add("https://www.eteams.cn/crms/saleChance?menu=key_all|state_0|module_saleChance|targetId_406&search=view_|searchId_406&table=view_&info=view_SaleChanceView|saleChanceId_4732608807705504048&tab=type_");
            //chanceUrlList.Add("https://www.eteams.cn/crms/saleChance?menu=key_all|state_0|module_saleChance|targetId_406&search=view_|searchId_406&table=view_&info=view_SaleChanceView|saleChanceId_8472683743121686769&tab=type_");
            //var comparedate = DateTime.Parse(DateTime.Now.AddDays(-1).ToString("yyyy-MM-dd"));
            var etramList = businesschanceHelper.FindList(x => x.Id>0).OrderByDescending(x =>x.Id);


            foreach (var eteamsChance in etramList)
            {

                //if (eteamsChance.EteamsId != "8472683743117786740")
                //{
                //    continue;
                //}

                var url = string.Format("https://weapp.eteams.cn/crm/salechance/9081908547940234461/list/all/detail/{0}", eteamsChance.EteamsId);
                Logger.Log("开始更新地址" + url);
                webDriver.Navigate().GoToUrl(url);

                System.Threading.Thread.Sleep(10000);

                try
                {
                    GetChanceDeatil(businesschanceHelper, eteamsChance, url);

                }
                catch (Exception ex)
                {
                   
                    try
                    {
                        Logger.Log("重刷界面");
                        webDriver.Navigate().Refresh();
                        System.Threading.Thread.Sleep(10000);
                        GetChanceDeatil(businesschanceHelper, eteamsChance, url);

                    }
                    catch(Exception ex2)
                    {
                        var msg = "Get Chance Failure:" + url;
                        Logger.Log(msg);
                        stringBuilder.Append(msg);
                        Logger.Log(ex2);
                    }




                }
                Logger.Log("更新地址结束" + url);


            }
        }

        private void GetChanceDeatil(DBHelper<businesschance> businesschanceHelper, businesschance eteamsChance, string url)
        {
          

            bool isDelete = false;
            try
            {
                //判断是不是被作废和逻辑删除
                var displaytext = webDriver.FindElement(By.XPath("//*[@id=\"ui-dialog-header-draggable\"]/div/div[1]/div/div[2]/div[1]/div/span[2]")).Text;
                if (displaytext == "此商机已被移到回收站")
                {
                    isDelete = true;
                }

            }
            catch { }

            if (!isDelete)
            {
                try
                {
                    //判断是不是被作废和逻辑删除
                    var chanceNode = webDriver.FindElement(By.Id("js_loadding"));
                    if (chanceNode.Displayed)
                    {
                        isDelete = true;
                    }

                }
                catch { }
            }





            if (!isDelete)
            {

                //*[@id="dialog_tj2xi4"]
                var dialogid = webDriver.FindElement(By.CssSelector(".ui-dialog-wrap.ui-dialog-wrap-right.ui-dialog-content-scale")).GetAttribute("id");

                Logger.Log("dialogid" + dialogid);

                var chanceCode = webDriver.FindElement(By.XPath("//*[@id=\"widget_2182165012281802449\"]/div[2]/div[2]/label")).Text;

                Logger.Log("chanceCode" + chanceCode);
                var chancename = webDriver.FindElement(By.XPath("//*[@id=\"" + dialogid + "\"]/div[2]/div/div/div/div[2]/div/div/div/div/div/div/div/div[2]/div[1]/div[1]/div[2]/input")).GetAttribute("value");
                Logger.Log("chancename" + chancename);
                var managerName = webDriver.FindElement(By.XPath("//*[@id=\"" + dialogid + "\"]/div[2]/div/div/div/div[2]/div/div/div/div/div/div/div/div[2]/div[2]/div/div[1]/div/div[2]/div/div/div/div/div/div/div/div/div/div/div/div/div/span")).Text;
                Logger.Log("managerName" + managerName);
                //销售金额
                var money = webDriver.FindElement(By.Id("money")).GetAttribute("value");
                Logger.Log("money" + money);
                //商机阶段
                var chancestage = webDriver.FindElement(By.XPath("//*[@id=\"" + dialogid + "\"]/div[2]/div/div/div/div[2]/div/div/div/div/div/div/div/div[2]/div[2]/div/div[2]/div/div[2]/div/div/div/span/span/span/div/span[1]/div/div/div/div/div/div/div/div/div/div/span")).Text;
                Logger.Log("chancestage" + chancestage);
                //商机赢率
                var winrate = webDriver.FindElement(By.XPath("//*[@id=\"" + dialogid + "\"]/div[2]/div/div/div/div[2]/div/div/div/div/div/div/div/div[2]/div[3]/div[1]/div[2]/div/div[2]/div/div/div/div/div/span[1]")).Text.Replace("%", "").Replace("请选择", "");
                Logger.Log("winrate" + winrate);
                //所属客户
                var customerName = webDriver.FindElement(By.XPath("//*[@id=\"" + dialogid + "\"]/div[2]/div/div/div/div[2]/div/div/div/div/div/div/div/div[2]/div[3]/div[3]/div[1]/div/div[2]/div/div/div/span/span/span/div/span[1]/div/div/div/div/div/div/div/div/div/div/span")).Text;
                Logger.Log("customerName" + customerName);
                //商机类型
                var chanceType = webDriver.FindElement(By.XPath("//*[@id=\"" + dialogid + "\"]/div[2]/div/div/div/div[2]/div/div/div/div/div/div/div/div[2]/div[3]/div[2]/div[2]/div/div[2]/div/div/div/span/span/span/div/span[1]/div/div/div/div/div/div/div/div/div/div/span")).Text;
                Logger.Log("chanceType" + chanceType);
                //商机大类
                var category = webDriver.FindElement(By.XPath("//*[@id=\"widget_4743193737385227535\"]/div[2]/div[2]/div/div/div/span[1]")).Text;
                Logger.Log("category" + category);

                //售前负责人
                var presales = string.Empty;
                try
                {
               
                    presales = webDriver.FindElement(By.XPath("//*[@id=\"widget_1473472292671572782\"]/div[2]/div[2]/div/div/div/span[1]")).Text;
                    Logger.Log("presales" + presales);
                }
                catch
                {
                    //Logger.Log("售前负责人为空" + url);
                }


                var dept = string.Empty;
            

                dept = webDriver.FindElement(By.XPath("//*[@id=\"widget_4742641986291346223\"]/div[2]/div[2]/div/div/div/span[1]")).Text;
                Logger.Log("dept" + dept);

                //预计PO时间
                var prepotime = webDriver.FindElement(By.XPath("//*[@id=\"widget_7963030243256199806\"]/div[2]/div[2]/div/div/div/input")).GetAttribute("value");
                Logger.Log("prepotime" + prepotime);
                //实际PO时间
                var actupotime = webDriver.FindElement(By.XPath("//*[@id=\"widget_7962911296615139707\"]/div[2]/div[2]/div/div/div/input")).GetAttribute("value");
                Logger.Log("actupotime" + actupotime);
                //预计开票时间
                var invoicetime = webDriver.FindElement(By.XPath("//*[@id=\"widget_7962911296615139705\"]/div[2]/div[2]/div/div/div/input")).GetAttribute("value");
                Logger.Log("invoicetime" + invoicetime);





                //判断先前是否同步到本地



                eteamsChance.ChanceName = chancename;
                eteamsChance.ChanceCode = chanceCode;
                eteamsChance.chancestage = chancestage;
                eteamsChance.ManagerName = managerName;
                eteamsChance.Money = null;
                if (!string.IsNullOrEmpty(money))
                {
                    eteamsChance.Money = decimal.Parse(money);
                }
                eteamsChance.Winrate = null;
                if (!string.IsNullOrEmpty(winrate))
                {
                    eteamsChance.Winrate = decimal.Parse(winrate);
                }

                eteamsChance.CustomerName = customerName;
                eteamsChance.ChanceType = chanceType;
                eteamsChance.Presales = presales;
                eteamsChance.Dept = dept;
                eteamsChance.PrepoTime = null;
                if (!string.IsNullOrEmpty(prepotime))
                {
                    eteamsChance.PrepoTime = DateTime.Parse(prepotime);
                }

                eteamsChance.ActupoTime = null;
                if (!string.IsNullOrEmpty(actupotime))
                {
                    eteamsChance.ActupoTime = DateTime.Parse(actupotime);
                }

                eteamsChance.InvoiceTime = null;
                if (!string.IsNullOrEmpty(invoicetime))
                {
                    eteamsChance.InvoiceTime = DateTime.Parse(invoicetime);
                }
                eteamsChance.category = category;
            }
            else
            {
                eteamsChance.IsDelete = isDelete;
            }

            //eteamsChance.UpdateTime = DateTime.Now;


            businesschanceHelper.Update(eteamsChance);



            DBHelper<businesschancehistory> businesschancehistoryHelper = new DBHelper<businesschancehistory>();

            businesschancehistory businesschancehistory = new businesschancehistory();
            businesschancehistory.EteamsId = eteamsChance.EteamsId;
            businesschancehistory.ChanceCode = eteamsChance.ChanceCode;
            businesschancehistory.ChanceName = eteamsChance.ChanceName;
            businesschancehistory.ManagerName = eteamsChance.ManagerName;
            businesschancehistory.chancestage = eteamsChance.chancestage;
            businesschancehistory.Money = eteamsChance.Money;
            businesschancehistory.Winrate = eteamsChance.Winrate;
            businesschancehistory.CustomerName = eteamsChance.CustomerName;
            businesschancehistory.Presales = eteamsChance.Presales;
            businesschancehistory.Dept = eteamsChance.Dept;
            businesschancehistory.PrepoTime = eteamsChance.PrepoTime;
            businesschancehistory.ActupoTime = eteamsChance.ActupoTime;
            businesschancehistory.InvoiceTime = eteamsChance.InvoiceTime;
            businesschancehistory.CreateTime = eteamsChance.UpdateTime;
            businesschancehistory.category = eteamsChance.category;
            businesschancehistoryHelper.Add(businesschancehistory);
            Logger.Log("SUCCESS:" + url);
        }

        StringBuilder stringBuilder = new StringBuilder();
        bool autorun = true;
        private void Form1_Load(object sender, EventArgs e)
        {
            

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Login();

            GetContractNew();

            CloseProcess();

        }



        private void GetContractNew()
        {
            Logger.Log("开始获取合同内信息");
            //跳转到我的全部合同
            webDriver.Navigate().GoToUrl("https://weapp.eteams.cn/crm/contract/9081908547940234461/list/all");
            //webDriver.FindElement(By.XPath("//*[@id='mCSB_2_container']/ul/li[1]/ul/li[6]/a")).Click();

            System.Threading.Thread.Sleep(5000);


            //获取总页数

            var totalPageNode = webDriver.FindElement(By.CssSelector(".ui-pagination-total.ui-pagination-placeholder"));
            if (!totalPageNode.Displayed)
            {
                Actions action = new Actions(webDriver);
                action.MoveToElement(totalPageNode);
                action.Perform();
            }

            var totalNum = Int32.Parse(totalPageNode.Text.Replace("共", "").Replace("条", ""));




            //在最后一页中获取最新的记录插入数据库
            DBHelper<businesscontract> businesscontractHelper = new DBHelper<businesscontract>();
            //
            DBHelper<businesscontracthistory> businesscontracthistoryHelper = new DBHelper<businesscontracthistory>();

            DBHelper<businesscontractandchance> businesscontractandchanceHelper = new DBHelper<businesscontractandchance>();
            //
            DBHelper<businesscontractandchancehi> businesscontractandchancehiHelper = new DBHelper<businesscontractandchancehi>();


            DBHelper<businesscontractstage> businesscontractstageHelper = new DBHelper<businesscontractstage>();
            DBHelper<businesscontractstagehistory> businesscontractstagehistoryHelper = new DBHelper<businesscontractstagehistory>();




            if (autorun)
            {





                var cntractlist = webDriver.FindElements(By.XPath("//*[@id=\"modulePanel\"]/div/div/div/div/div[2]/div/div/div[3]/div/div/div/div[1]/div[1]/table/tbody/tr"));

                foreach (var cntract in cntractlist)
                {
                    var tds = cntract.FindElements(By.TagName("td"));
                    var contractname = tds[1].Text.Trim();


                    var contractid = cntract.GetAttribute("data-id");
                    var checkExit = businesscontractHelper.FindList(x => x.EteamsContractId == contractid);
                    if (checkExit.Count == 0)
                    {
                        businesscontract newbusinesscontract = new businesscontract();
                        newbusinesscontract.EteamsContractId = contractid;
                        newbusinesscontract.CreateTime = DateTime.Now;
                        newbusinesscontract.ContractName = contractname.Replace(" ", "");
                        businesscontractHelper.Add(newbusinesscontract);
                    }
                    else
                    {
                        checkExit[0].UpdateTime = DateTime.Now;
                        checkExit[0].ContractName = contractname.Replace(" ", "");
                        businesscontractHelper.Update(checkExit[0]);
                    }

                }

                Thread.Sleep(3000);

                //获取点击下一页的次数
                int clickNextTime = totalNum / 30;

                for (int i = 0; i <= clickNextTime; i++)
                {
                    var nextNode = webDriver.FindElement(By.CssSelector(".ui-pagination-pager-item.ui-pagination-pager-next"));
                    if (!nextNode.Displayed)
                    {
                        Actions action = new Actions(webDriver);
                        action.MoveToElement(nextNode);
                        nextNode.Click();
                        action.Perform();
                    }





                    IJavaScriptExecutor javaScriptExecutor = (IJavaScriptExecutor)webDriver;
                    javaScriptExecutor.ExecuteScript("arguments[0].click();", nextNode);

                    System.Threading.Thread.Sleep(6000);



                    cntractlist = webDriver.FindElements(By.XPath("//*[@id=\"modulePanel\"]/div/div/div/div/div[2]/div/div/div[3]/div/div/div/div[1]/table/tbody/tr"));

                    foreach (var cntract in cntractlist)
                    {
                        var contractid = cntract.GetAttribute("data-id");
                        var tds = cntract.FindElements(By.TagName("td"));
                        var contractname = tds[1].Text.Trim();

                        var checkExit = businesscontractHelper.FindList(x => x.EteamsContractId == contractid);
                        if (checkExit.Count == 0)
                        {
                            businesscontract newbusinesscontract = new businesscontract();
                            newbusinesscontract.EteamsContractId = contractid;
                            newbusinesscontract.CreateTime = DateTime.Now;
                            newbusinesscontract.ContractName = contractname.Replace(" ", ""); ;
                            businesscontractHelper.Add(newbusinesscontract);
                        }
                        else
                        {
                            checkExit[0].UpdateTime = DateTime.Now;
                            checkExit[0].ContractName = contractname.Replace(" ", "");
                            businesscontractHelper.Update(checkExit[0]);
                        }

                    }

                    Thread.Sleep(3000);
                }

            }











            var contractList = businesscontractHelper.FindList(x => x.Id > 0);


            foreach (var contract in contractList)
            {

                //if (contract.EteamsContractId != "4733159767653484505")
                //{
                //    continue;
                //}


                var url = string.Format("https://weapp.eteams.cn/crm/contract/9081908547940234461/list/all/contractViewPage/{0}", contract.EteamsContractId);

                Logger.Log("开始获取合同详细信息" + url);

                //url = "https://www.eteams.cn/crms/contract?menu=key_all|state_0|module_contract|targetId_506&search=view_&table=view_&info=view_ContractView|contractId_8472303386626503805&tab=type_";
                try
                {

                    webDriver.Navigate().GoToUrl(url);

                    System.Threading.Thread.Sleep(10000);
                  
                    GetContractDetail(businesscontractHelper, businesscontracthistoryHelper, businesscontractandchanceHelper, businesscontractandchancehiHelper, businesscontractstageHelper, businesscontractstagehistoryHelper, contract, url);

                }
                catch (Exception ex)
                {
                    try
                    {
                        webDriver.Navigate().Refresh();
                        System.Threading.Thread.Sleep(10000);
                        GetContractDetail(businesscontractHelper, businesscontracthistoryHelper, businesscontractandchanceHelper, businesscontractandchancehiHelper, businesscontractstageHelper, businesscontractstagehistoryHelper, contract, url);

                    }
                    catch(Exception ex2)
                    {
                        var msg = "Get contract Failure:" + url;
                        Logger.Log(msg);
                        stringBuilder.Append(msg);
                        Logger.Log(ex2);

                    }

                }

                Logger.Log("结束获取合同详细信息" + url);


            }
        }

        private void GetContractDetail(DBHelper<businesscontract> businesscontractHelper, DBHelper<businesscontracthistory> businesscontracthistoryHelper, DBHelper<businesscontractandchance> businesscontractandchanceHelper, DBHelper<businesscontractandchancehi> businesscontractandchancehiHelper, DBHelper<businesscontractstage> businesscontractstageHelper, DBHelper<businesscontractstagehistory> businesscontractstagehistoryHelper, businesscontract contract, string url)
        {
            bool isCancle = false;

            bool isDelete = false;

            try
            {
                //判断是不是被作废和逻辑删除
                var displaytext = webDriver.FindElement(By.CssSelector(".clue-eui-gapbar-span.ml-70")).Text;
                if (displaytext == "此合同已作废")
                {
                    isCancle = true;
                }
                else if (displaytext == "此合同已被移到回收站")
                {
                    isDelete = true;
                }

            }
            catch { }

            try
            {

                if (!isCancle && !isDelete)
                {
                    //判断是不是被删除
                    var deletetext = webDriver.FindElement(By.CssSelector(".alert-heading")).Text;
                    if (deletetext == "对不起! 你访问的数据服务器不存在")
                    {
                        isDelete = true;
                    }
                }
            }
            catch { }


            //判断是不是被删除
            var dialogid = "";
            string contentdiv = "div[2]/div/div/div/div[2]/div/div/div/div/div/div/div/div[1]";
            string stagediv = "div[2]/div/div/div/div[2]/div/div/div/div/div/div/div/div[2]";

            if (!isCancle && !isDelete)
            {
                dialogid = webDriver.FindElement(By.CssSelector(".ui-dialog-wrap.ui-dialog-wrap-right.ui-dialog-content-scale")).GetAttribute("id");

     

                var tempInfos = webDriver.FindElements(By.CssSelector(".crm_contractApprover_spanInfo.js_approverInfo"));
                if(tempInfos.Count >0)
                {
                     contentdiv = "div[2]/div/div/div/div[2]/div/div/div/div/div/div/div/div[2]";
                     stagediv = "div[2]/div/div/div/div[2]/div/div/div/div/div/div/div/div[3]";
                }




                //合同编号
                var contractCode = webDriver.FindElement(By.XPath("//*[@id=\"widget_8752165214771160849\"]/div[2]/div[2]/input")).GetAttribute("value");
                //名称
                var contractname = webDriver.FindElement(By.XPath("//*[@id=\"" + dialogid + "\"]/" + contentdiv  + "/div[1]/div/div[2]/input")).GetAttribute("value").Replace(" ", "");
                //负责人
                var managerName = webDriver.FindElement(By.XPath("//*[@id=\"" + dialogid + "\"]/" + contentdiv + "/div[2]/div/div[2]/div/div[2]/div/div/div/div/div/div/div/div/div/div/div/div/div/span")).Text;
                //所属客户
                var customerName = webDriver.FindElement(By.XPath("//*[@id=\"" + dialogid + "\"]/" + contentdiv + "/div[2]/div/div[2]/div/div[2]/div/div/div/div/div/div/div/div/div/div/div/div/div/span")).Text;
                //类型
                var contractType = webDriver.FindElement(By.XPath("//*[@id=\"" + dialogid + "\"]/" + contentdiv + "/div[3]/div[1]/div[1]/div/div[2]/div/div/div[1]/span/span/span/div/span[1]/div/div/div/div/div/div/div/div/div/div/span")).Text;
                //金额
                var money = webDriver.FindElement(By.Id("totalMoney")).GetAttribute("value").Replace(",", "");
                //状态
                var status = webDriver.FindElement(By.XPath("//*[@id=\"" + dialogid + "\"]/" + contentdiv + "/div[3]/div[2]/div[1]/div/div[2]/div/div/div/span/span/span/div/span[1]/div/div/div/div/div/div/div/div/div/div/span")).Text;
                //***开始时间
                var begintime = webDriver.FindElement(By.XPath("//*[@id=\"" + dialogid + "\"]/" + contentdiv + "/div[3]/div[2]/div[2]/div/div[2]/div/div/div/div/div/input")).GetAttribute("value");
                //***结束时间
                var endtime = webDriver.FindElement(By.XPath("//*[@id=\"" + dialogid + "\"]/" + contentdiv + "/div[3]/div[3]/div/div/div[2]/div/div/div/div/div/input")).GetAttribute("value");
                //大类
                var category = webDriver.FindElement(By.XPath("//*[@id=\"widget_7962383096624829980\"]/div[2]/div[2]/div/div/div/span[1]")).Text;
                //小类
                var subcategory = webDriver.FindElement(By.XPath("//*[@id=\"widget_7962667962516579439\"]/div[2]/div[2]/div/div/div/span[1]")).Text;

                //签约时间
                var signtime = webDriver.FindElement(By.XPath("//*[@id=\"" + dialogid + "\"]/" + contentdiv + "/div[3]/div[6]/div/div/div[2]/div/div/div[1]/div/div/input")).GetAttribute("value");

                var paymentday = webDriver.FindElement(By.XPath("//*[@id=\"widget_4742995096437444553\"]/div[2]/div[2]/input")).GetAttribute("value");
                ////关联商机
                //var chanceid = string.Empty;
                //var chanceName = string.Empty;
                try
                {
                    //var chanceNode = webDriver.FindElement(By.XPath("//div[@class='js_relateitem_container relevance-card j_relevance-card j_item-container']/span/a[1]"));
                    //chanceid = chanceNode.GetAttribute("data-id");
                    //chanceName = chanceNode.Text;



                    var chanceNodes = webDriver.FindElements(By.XPath("//*[@id=\"widget_8752165214771160848\"]/div[2]/div[2]/div/div/div/div/div[1]/div/div[1]/div/div/div"));
                    businesscontractandchanceHelper.RemoveList(x => x.EteamsContractId == contract.EteamsContractId);
                    foreach (var chanceNode in chanceNodes)
                    {
                        var chanceid = chanceNode.GetAttribute("data-id");
                        var chanceName = chanceNode.Text;

                        businesscontractandchance newbcc = new businesscontractandchance();
                        newbcc.EteamsChanceId = chanceid;
                        newbcc.EteamsContractId = contract.EteamsContractId;
                        newbcc.Createtime = DateTime.Now;
                        businesscontractandchanceHelper.Add(newbcc);

                        businesscontractandchancehi newbcch = new businesscontractandchancehi();
                        newbcch.EteamsChanceId = chanceid;
                        newbcch.EteamsContractId = contract.EteamsContractId;
                        newbcch.UpdateTime = DateTime.Now;
                        businesscontractandchancehiHelper.Add(newbcch);
                    }

                }
                catch (Exception ex)
                {

                    Logger.Log(ex);
                }


                var percentDeliveryCenter = webDriver.FindElement(By.XPath("//*[@id=\"widget_4742684331421555065\"]/div[2]/div[2]/div/input")).GetAttribute("value");
                var percentDevCenter = webDriver.FindElement(By.XPath("//*[@id=\"widget_4742684331421555067\"]/div[2]/div[2]/div/input")).GetAttribute("value");
                var percentSuccessCenter = webDriver.FindElement(By.XPath("//*[@id=\"widget_4742684331421555066\"]/div[2]/div[2]/div/input")).GetAttribute("value");
                var percentOtherCenter = webDriver.FindElement(By.XPath("//*[@id=\"widget_4742684331421555068\"]/div[2]/div[2]/div/input")).GetAttribute("value");
                //--封装对象
                //contract.ContractName = contractname;

                contract.Customer = customerName;
                contract.Manager = managerName;
                contract.ContractType = contractType;
                contract.TotalAmount = 0;
                if (!string.IsNullOrEmpty(money))
                {
                    contract.TotalAmount = Decimal.Parse(money);
                }
                contract.Status = status;
                if (!string.IsNullOrEmpty(begintime))
                {
                    contract.BeginTime = DateTime.Parse(begintime);
                }
                if (!string.IsNullOrEmpty(endtime))
                {
                    contract.EndTime = DateTime.Parse(endtime);
                }

                if (!string.IsNullOrEmpty(paymentday))
                {
                    contract.paymentday = Int32.Parse(paymentday);
                }

                contract.Category = category;
                contract.SubCategory = subcategory;
                //contract.EteamsChanceId = chanceid;
                //contract.EteamsChanceName = chanceName;



                contract.ContractCode = contractCode;

                if (!string.IsNullOrEmpty(percentDeliveryCenter))
                {
                    contract.PercentDeliveryCenter = Decimal.Parse(percentDeliveryCenter); ;
                }
                else
                {
                    contract.PercentDeliveryCenter = 0;
                }
                if (!string.IsNullOrEmpty(percentDevCenter))
                {
                    contract.PercentDevCenter = Decimal.Parse(percentDevCenter);
                }
                else
                {
                    contract.PercentDevCenter = 0;
                }

                if (!string.IsNullOrEmpty(percentOtherCenter))
                {
                    contract.PercentOtherCenter = Decimal.Parse(percentOtherCenter);
                }
                else
                {
                    contract.PercentOtherCenter = 0;
                }

                if (!string.IsNullOrEmpty(percentSuccessCenter))
                {
                    contract.PercentSuccessCenter = Decimal.Parse(percentSuccessCenter);
                }
                else
                {
                    contract.PercentSuccessCenter = 0;
                }

                if (!string.IsNullOrEmpty(signtime))
                {
                    contract.SignedTime = DateTime.Parse(signtime); ;
                }
            }
            else
            {
                contract.IsCancle = isCancle;
                contract.IsDelete = isDelete;
            }



            contract.UpdateTime = DateTime.Now;

            businesscontractHelper.Update(contract);

            //插入历史记录

            businesscontracthistory businesscontracthistory = new businesscontracthistory();
            //--封装对象
            businesscontracthistory.EteamsContractId = contract.EteamsContractId;
            businesscontracthistory.Manager = contract.Manager;
            businesscontracthistory.Customer = contract.Customer;
            businesscontracthistory.ContractType = contract.ContractType;
            businesscontracthistory.ContractName = contract.ContractName;
            businesscontracthistory.TotalAmount = contract.TotalAmount;
            businesscontracthistory.Status = contract.Status;
            businesscontracthistory.BeginTime = contract.BeginTime;
            businesscontracthistory.EndTime = contract.EndTime;
            businesscontracthistory.Category = contract.Category;
            businesscontracthistory.SubCategory = contract.SubCategory;
            businesscontracthistory.paymentday = contract.paymentday;
            businesscontracthistory.ContractCode = contract.ContractCode;
            businesscontracthistory.PercentDeliveryCenter = contract.PercentDeliveryCenter;
            businesscontracthistory.PercentDevCenter = contract.PercentDevCenter;
            businesscontracthistory.PercentOtherCenter = contract.PercentOtherCenter;
            businesscontracthistory.PercentSuccessCenter = contract.PercentSuccessCenter;
            businesscontracthistory.SignedTime = contract.SignedTime;
            businesscontracthistory.CreateTime = contract.UpdateTime;
            businesscontracthistory.IsCancle = contract.IsCancle;
            businesscontracthistory.IsDelete = contract.IsDelete;

            businesscontracthistoryHelper.Add(businesscontracthistory);

            if (!isCancle && !isDelete)
            {
                //删除所有批次号

                businesscontractstageHelper.RemoveList(x => x.EteamsContractID == contract.EteamsContractId);

                //获取付款批次

                //定位关联事件
                var linkeventmark = webDriver.FindElement(By.CssSelector(".ui-card-detail-form-tags-footer.ui-card-detail-form-tags-footer-hidden"));
                if (!linkeventmark.Displayed)
                {
                    Actions action = new Actions(webDriver);
                    action.MoveToElement(linkeventmark);
                    action.Perform();
                }
                System.Threading.Thread.Sleep(500);


                var stageDivList = webDriver.FindElements(By.XPath("//*[@id=\"" + dialogid + "\"]/" + stagediv + "/div[2]/div/div"));

                if (stageDivList.Count > 0)
                {
                    foreach (var stageDiv in stageDivList)
                    {


                        try
                        {
                            if (!stageDiv.Displayed)
                            {
                                Actions action = new Actions(webDriver);
                                action.MoveToElement(stageDiv);
                                action.Perform();
                                System.Threading.Thread.Sleep(500);
                            }

                            var stageSpans = stageDiv.FindElement(By.CssSelector(".weapp-crm-card-period-periodItem-description")).FindElements(By.XPath("span"));

                            //var stageId = stageSpan.GetAttribute("id").Replace("_stageDate", "");



                            var stageName = stageSpans[0].Text;
                            var targettime = stageSpans[1].Text.Replace("预计", "").Replace(" ", "");

                            var stageAmount = stageSpans[2].Text.Replace("金额", "").Replace("元", "").Replace(" ", "").Replace(",", "");






                            businesscontractstage stage = new businesscontractstage();

                            stage.ContractName = contract.ContractName;
                            stage.EteamsContractID = contract.EteamsContractId;
                            stage.StageName = stageName;
                            //stage.EteamsContractStageID = stageId;
                            if (!string.IsNullOrEmpty(stageAmount))
                            {
                                stage.StageAmount = decimal.Parse(stageAmount);
                            }

                            if (!string.IsNullOrEmpty(targettime))
                            {
                                stage.TargetTime = DateTime.Parse(targettime);
                            }
                            stage.CreateTime = DateTime.Now;
                            stage.UpdateTime = stage.CreateTime;

                            businesscontractstageHelper.Add(stage);

                            businesscontractstagehistory stagehistory = new businesscontractstagehistory();
                            stagehistory.ContractName = contract.ContractName;
                            stagehistory.EteamsContractID = contract.EteamsContractId;
                            stagehistory.StageName = stage.StageName;
                            stagehistory.EteamsContractStageID = stage.EteamsContractStageID;
                            stagehistory.StageAmount = stage.StageAmount;
                            stagehistory.TargetTime = stage.TargetTime;
                            stagehistory.CreateTime = stage.CreateTime;
                            businesscontractstagehistoryHelper.Add(stagehistory);
                        }
                        catch (Exception ex)
                        {
                            Logger.Log("获取期次失败" + url);
                        }

                    }
                }
            }

            Logger.Log("SUCCESS:" + url);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Login();
            GetInvoice();

            CloseProcess();
        }

        private void GetInvoice()
        {
            //跳转开票
            webDriver.Navigate().GoToUrl("https://weapp.eteams.cn/crm/contract/9081908547940234461/ledger/list/invoice");
            //webDriver.FindElement(By.XPath("//*[@id='mCSB_2_container']/ul/li[1]/ul/li[6]/a")).Click();

            System.Threading.Thread.Sleep(5000);

            //获取总页数

            var totalPageNode = webDriver.FindElement(By.CssSelector(".ui-pagination-total.ui-pagination-placeholder"));
            if (!totalPageNode.Displayed)
            {
                Actions action = new Actions(webDriver);
                action.MoveToElement(totalPageNode);
                action.Perform();
            }

            var totalNum = Int32.Parse(totalPageNode.Text.Replace("共", "").Replace("条", ""));


            //在最后一页中获取最新的记录插入数据库
            DBHelper<businesscontractinvoice> businesscontractinvoiceHelper = new DBHelper<businesscontractinvoice>();
            //
            DBHelper<businesscontractinvoicehistory> businesscontractinvoicehistoryHelper = new DBHelper<businesscontractinvoicehistory>();

            DBHelper<businesscontract> businesscontractHelper = new DBHelper<businesscontract>();

            var invoicelist = webDriver.FindElements(By.XPath("//*[@id=\"modulePanel\"]/div/div/div/div/div[2]/div/div/div[3]/div/div/div[1]/table/tbody/tr"));

            foreach (var invoice in invoicelist)
            {
                var invoiceId = invoice.GetAttribute("data-id");
                var tds = invoice.FindElements(By.TagName("td"));

                var checkExit = businesscontractinvoiceHelper.FindList(x => x.EteamsInvocieID == invoiceId);

                var contractname = tds[1].Text.Trim().Replace(" ", ""); ;
                var etreamContractId = "";
                var contractList = businesscontractHelper.FindList(x => x.ContractName == contractname);
                if(contractList.Count==1)
                {
                    etreamContractId = contractList[0].EteamsContractId;
                }

                if (checkExit.Count == 0)
                {
                    businesscontractinvoice newbusinesscontractinvoice = new businesscontractinvoice();
                    newbusinesscontractinvoice.EteamsInvocieID = invoiceId;
                    newbusinesscontractinvoice.InvoiceAmount = Decimal.Parse(tds[3].Text.Replace(",", ""));
                    newbusinesscontractinvoice.InvoiceTime = DateTime.Parse(tds[4].Text);
                    newbusinesscontractinvoice.ContractName = tds[1].Text.Trim().Replace(" ", ""); ;
                    newbusinesscontractinvoice.EteamsContractID = etreamContractId;
                    newbusinesscontractinvoice.StageName = tds[2].Text.Trim();
                    newbusinesscontractinvoice.createtime = DateTime.Now;
                    newbusinesscontractinvoice.updatetime = DateTime.Now;
                    businesscontractinvoiceHelper.Add(newbusinesscontractinvoice);
                }
                else
                {
                    checkExit[0].updatetime = DateTime.Now;
                    checkExit[0].InvoiceAmount = Decimal.Parse(tds[3].Text.Replace(",", ""));
                    checkExit[0].InvoiceTime = DateTime.Parse(tds[4].Text);
                    checkExit[0].ContractName = tds[1].Text.Trim().Replace(" ", ""); ;
                    checkExit[0].EteamsContractID = etreamContractId;
                    checkExit[0].StageName = tds[2].Text.Trim();

                    checkExit[0].updatetime = DateTime.Now;
                    businesscontractinvoiceHelper.Update(checkExit[0]);
                }

            }

            //获取点击下一页的次数
            int clickNextTime = totalNum / 30;

            for (int i = 0; i <= clickNextTime; i++)
            {
                var nextNode = webDriver.FindElement(By.CssSelector(".ui-pagination-pager-item.ui-pagination-pager-next"));
                if (!nextNode.Displayed)
                {
                    Actions action = new Actions(webDriver);
                    action.MoveToElement(nextNode);
                    nextNode.Click();
                    action.Perform();
                }

                IJavaScriptExecutor javaScriptExecutor = (IJavaScriptExecutor)webDriver;
                javaScriptExecutor.ExecuteScript("arguments[0].click();", nextNode);

                System.Threading.Thread.Sleep(2000);


                invoicelist = webDriver.FindElements(By.XPath("//*[@id=\"modulePanel\"]/div/div/div/div/div[2]/div/div/div[3]/div/div/div[1]/table/tbody/tr"));

                foreach (var invoice in invoicelist)
                {
                    var invoiceId = invoice.GetAttribute("data-id");

                    var tds = invoice.FindElements(By.TagName("td"));


                    var checkExit = businesscontractinvoiceHelper.FindList(x => x.EteamsInvocieID == invoiceId);
                    var contractname = tds[1].Text.Trim().Replace(" ", ""); ;
                    var etreamContractId = "";
                    var contractList = businesscontractHelper.FindList(x => x.ContractName == contractname);
                    if (contractList.Count == 1)
                    {
                        etreamContractId = contractList[0].EteamsContractId;
                    }
                    if (checkExit.Count == 0)
                    {
                        businesscontractinvoice newbusinesscontractinvoice = new businesscontractinvoice();
                        newbusinesscontractinvoice.EteamsInvocieID = invoiceId;
                        newbusinesscontractinvoice.InvoiceAmount = Decimal.Parse(tds[3].Text.Replace(",", ""));
                        newbusinesscontractinvoice.InvoiceTime = DateTime.Parse(tds[4].Text);
                        newbusinesscontractinvoice.ContractName = tds[1].Text.Trim().Replace(" ", ""); ;
                        newbusinesscontractinvoice.EteamsContractID = etreamContractId;
                        newbusinesscontractinvoice.StageName = tds[2].Text.Trim();
                        newbusinesscontractinvoice.createtime = DateTime.Now;
                        newbusinesscontractinvoice.updatetime = DateTime.Now;
                        businesscontractinvoiceHelper.Add(newbusinesscontractinvoice);
                    }
                    else
                    {
                        checkExit[0].updatetime = DateTime.Now;
                        checkExit[0].InvoiceAmount = Decimal.Parse(tds[3].Text.Replace(",", ""));
                        checkExit[0].InvoiceTime = DateTime.Parse(tds[4].Text);
                        checkExit[0].ContractName = tds[1].Text.Trim().Replace(" ", ""); ;
                        checkExit[0].EteamsContractID = etreamContractId;
                        checkExit[0].StageName = tds[2].Text.Trim();
           
                        checkExit[0].updatetime = DateTime.Now;
                        businesscontractinvoiceHelper.Update(checkExit[0]);
                    }

                }

            }




           //var allInvoiceList = businesscontractinvoiceHelper.FindList(x => x.Id > 0).OrderByDescending(x =>x.Id);


           // foreach (var invoice in allInvoiceList)
           // {
           //     var url = string.Format("https://www.eteams.cn/crms/contractLedgerSetting?menu=key_contractInvoiceLedger|state_0|module_contract|targetId_&search=view_&table=view_&info=view_ContractInvoiceView|invoiceId_{0}&tab=type_contractInvoiceLedger", invoice.EteamsInvocieID);

           //     // url = "https://www.eteams.cn/crms/contract?menu=key_all|state_0|module_contract|targetId_506&search=view_&table=view_&info=view_ContractView|contractId_8472303386626503805&tab=type_";
           //     try
           //     {

           //         webDriver.Navigate().GoToUrl(url);

           //         System.Threading.Thread.Sleep(3000);


           //         var contractNode = webDriver.FindElement(By.CssSelector(".entity-item.js_contractName.j_showContract")).FindElement(By.TagName("a"));
           //         var contractName = contractNode.Text;
           //         var contractID = contractNode.GetAttribute("data-id");


           //         var stageNode = webDriver.FindElement(By.CssSelector(".entity-item.js_contractStageName")).FindElement(By.TagName("a"));
           //         var stageName = stageNode.Text;
           //         var stageID = stageNode.GetAttribute("data-id");


           //         var invoiceType = webDriver.FindElement(By.Id("contractInvoice-type")).Text;//

           //         var invoiceAmount = webDriver.FindElement(By.CssSelector(".form-control.js_field.js_invoice_money.textinput.contract-invoicemoney-input")).GetAttribute("value");//

           //         var invoiceTime = webDriver.FindElement(By.Id("invoiceTime")).GetAttribute("value");//



           //         invoice.ContractName = contractName;
           //         invoice.EteamsContractID = contractID;

           //         invoice.EteamsContractStageID = stageID;
           //         invoice.StageName = stageName;

           //         invoice.InvoiceType = invoiceType;

           //         if (!string.IsNullOrEmpty(invoiceAmount))
           //         {
           //             invoice.InvoiceAmount = Decimal.Parse(invoiceAmount);
           //         }


           //         if (!string.IsNullOrEmpty(invoiceTime))
           //         {
           //             invoice.InvoiceTime = DateTime.Parse(invoiceTime);
           //         }

           //         invoice.updatetime = DateTime.Now;

           //         businesscontractinvoiceHelper.Update(invoice);

           //         businesscontractinvoicehistory his = new businesscontractinvoicehistory();
           //         his.EteamsContractID = invoice.EteamsContractID;
           //         his.ContractName = invoice.ContractName;
           //         his.createtime = invoice.updatetime;
           //         his.EteamsContractStageID = invoice.EteamsContractStageID;
           //         his.StageName = invoice.StageName;
           //         his.InvoiceType = invoice.InvoiceType;
           //         his.InvoiceAmount = invoice.InvoiceAmount;
           //         his.InvoiceTime = invoice.InvoiceTime;

           //         businesscontractinvoicehistoryHelper.Add(his);



           //         Logger.Log("INVOICE SUCCESS:" + url);

           //     }
           //     catch (Exception ex)
           //     {
           //         invoice.updatetime = DateTime.Now;
           //         invoice.IsDelete = true;
           //         businesscontractinvoiceHelper.Update(invoice);

           //         var msg = "INVOICE Failure:" + url;
           //         Logger.Log(msg);
           //         stringBuilder.Append(msg);
           //         Logger.Log(ex);

           //     }


           // }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Login();
            GetReceive();

            CloseProcess();
        }

        private void GetReceive()
        {
            //跳转回款

            webDriver.Navigate().GoToUrl("https://weapp.eteams.cn/crm/contract/9081908547940234461/ledger/list/receive");
            //webDriver.FindElement(By.XPath("//*[@id='mCSB_2_container']/ul/li[1]/ul/li[6]/a")).Click();

            System.Threading.Thread.Sleep(5000);

            //获取总页数

            var totalPageNode = webDriver.FindElement(By.CssSelector(".ui-pagination-total.ui-pagination-placeholder"));
            if (!totalPageNode.Displayed)
            {
                Actions action = new Actions(webDriver);
                action.MoveToElement(totalPageNode);
                action.Perform();
            }

            var totalNum = Int32.Parse(totalPageNode.Text.Replace("共", "").Replace("条", ""));



            //在最后一页中获取最新的记录插入数据库
            DBHelper<businesscontractreceive> receiveHelper = new DBHelper<businesscontractreceive>();
            //
            DBHelper<businesscontractreceivehistory> receivehistoryHelper = new DBHelper<businesscontractreceivehistory>();

            DBHelper<businesscontract> businesscontractHelper = new DBHelper<businesscontract>();

            var receivelist = webDriver.FindElements(By.XPath("//*[@id=\"modulePanel\"]/div/div/div/div/div[2]/div/div/div[3]/div/div/div[1]/table/tbody/tr"));

            foreach (var invoice in receivelist)
            {
                var receiveId = invoice.GetAttribute("data-id");
                var tds = invoice.FindElements(By.TagName("td"));
                var checkExit = receiveHelper.FindList(x => x.ReceiveID == receiveId);

                var contractname = tds[1].Text.Trim().Replace(" ", "");;
                var etreamContractId = "";
                var contractList = businesscontractHelper.FindList(x => x.ContractName == contractname);
                if (contractList.Count == 1)
                {
                    etreamContractId = contractList[0].EteamsContractId;
                }

                if (checkExit.Count == 0)
                {
                    businesscontractreceive newreceive = new businesscontractreceive();
                    newreceive.ContractName = tds[1].Text.Trim().Replace(" ", ""); ;
                    newreceive.EteamsContractID = etreamContractId;
                    newreceive.ReceiveID = receiveId;
                    newreceive.ReceiveAmount = Decimal.Parse(tds[4].Text.Replace(",", ""));;
                    newreceive.ReceiveTime = DateTime.Parse(tds[5].Text);
                    newreceive.createtime = DateTime.Now;
                    newreceive.updatetime = DateTime.Now;
                    newreceive.StageName = tds[3].Text.Trim();
                    receiveHelper.Add(newreceive);
                }
                else
                {
                    checkExit[0].ContractName = tds[1].Text.Trim().Replace(" ", ""); ;
                    checkExit[0].EteamsContractID = etreamContractId;

                    checkExit[0].ReceiveAmount = Decimal.Parse(tds[4].Text.Replace(",", "")); ;
                    checkExit[0].ReceiveTime = DateTime.Parse(tds[5].Text);
                    checkExit[0].createtime = DateTime.Now;
                    checkExit[0].updatetime = DateTime.Now;
                    checkExit[0].StageName = tds[3].Text.Trim();
                    receiveHelper.Update(checkExit[0]);
                }

            }


            //获取点击下一页的次数
            int clickNextTime = totalNum / 30;

            for (int i = 0; i <= clickNextTime; i++)
            {
                var nextNode = webDriver.FindElement(By.CssSelector(".ui-pagination-pager-item.ui-pagination-pager-next"));
                if (!nextNode.Displayed)
                {
                    Actions action = new Actions(webDriver);
                    action.MoveToElement(nextNode);
                    nextNode.Click();
                    action.Perform();
                }

                IJavaScriptExecutor javaScriptExecutor = (IJavaScriptExecutor)webDriver;
                javaScriptExecutor.ExecuteScript("arguments[0].click();", nextNode);
                System.Threading.Thread.Sleep(2000);

                receivelist = webDriver.FindElements(By.XPath("//*[@id=\"modulePanel\"]/div/div/div/div/div[2]/div/div/div[3]/div/div/div[1]/table/tbody/tr"));

                foreach (var invoice in receivelist)
                {
                    var receiveId = invoice.GetAttribute("data-id");
                    var tds = invoice.FindElements(By.TagName("td"));
                    var checkExit = receiveHelper.FindList(x => x.ReceiveID == receiveId);

                    var contractname = tds[1].Text.Trim().Replace(" ", ""); ;
                    var etreamContractId = "";
                    var contractList = businesscontractHelper.FindList(x => x.ContractName == contractname);
                    if (contractList.Count == 1)
                    {
                        etreamContractId = contractList[0].EteamsContractId;
                    }

                    if (checkExit.Count == 0)
                    {
                        businesscontractreceive newreceive = new businesscontractreceive();
                        newreceive.ContractName = tds[1].Text.Trim().Replace(" ", ""); ;
                        newreceive.EteamsContractID = etreamContractId;
                        newreceive.ReceiveID = receiveId;
                        newreceive.ReceiveAmount = Decimal.Parse(tds[4].Text.Replace(",", "")); ;
                        newreceive.ReceiveTime = DateTime.Parse(tds[5].Text);
                        newreceive.createtime = DateTime.Now;
                        newreceive.updatetime = DateTime.Now;
                        newreceive.StageName = tds[3].Text.Trim();
                        receiveHelper.Add(newreceive);
                    }
                    else
                    {
                        checkExit[0].ContractName = tds[1].Text.Trim().Replace(" ", ""); ;
                        checkExit[0].EteamsContractID = etreamContractId;

                        checkExit[0].ReceiveAmount = Decimal.Parse(tds[4].Text.Replace(",", "")); ;
                        checkExit[0].ReceiveTime = DateTime.Parse(tds[5].Text);
                        checkExit[0].createtime = DateTime.Now;
                        checkExit[0].updatetime = DateTime.Now;
                        checkExit[0].StageName = tds[3].Text.Trim();
                        receiveHelper.Update(checkExit[0]);
                    }

                }

            }




                //var allReceive = receiveHelper.FindList(x => x.Id > 0);


                //foreach (var receive in allReceive)
                //{
                //    var url = string.Format("https://www.eteams.cn/crms/contractLedgerSetting?menu=key_contractReceiveLedger|state_0|module_contract|targetId_&search=view_&table=view_&info=view_ContractReceiveView|receiveId_{0}&tab=type_contractReceiveLedger", receive.ReceiveID);

                //    // url = "https://www.eteams.cn/crms/contract?menu=key_all|state_0|module_contract|targetId_506&search=view_&table=view_&info=view_ContractView|contractId_8472303386626503805&tab=type_";
                //    try
                //    {

                //        webDriver.Navigate().GoToUrl(url);

                //        System.Threading.Thread.Sleep(3000);


                //        var contractNode = webDriver.FindElement(By.CssSelector(".entity-item.js_contractName.j_showContract")).FindElement(By.TagName("a"));
                //        var contractName = contractNode.Text;
                //        var contractID = contractNode.GetAttribute("data-id");


                //        var stageNode = webDriver.FindElement(By.CssSelector(".entity-item.js_contractStageName")).FindElement(By.TagName("a"));
                //        var stageName = stageNode.Text;
                //        var stageID = stageNode.GetAttribute("data-id");



                //        var receiveAmount = webDriver.FindElement(By.CssSelector(".form-control.js_field.js_receive_money.textinput")).GetAttribute("value");//

                //        var receiveTime = webDriver.FindElement(By.Id("receiveTime")).GetAttribute("value");//



                //        receive.ContractName = contractName;
                //        receive.EteamsContractID = contractID;

                //        receive.EteamsContractStageID = stageID;
                //        receive.StageName = stageName;



                //        if (!string.IsNullOrEmpty(receiveAmount))
                //        {
                //            receive.ReceiveAmount = Decimal.Parse(receiveAmount);
                //        }


                //        if (!string.IsNullOrEmpty(receiveTime))
                //        {
                //            receive.ReceiveTime = DateTime.Parse(receiveTime);
                //        }

                //        receive.updatetime = DateTime.Now;

                //        receiveHelper.Update(receive);

                //        businesscontractreceivehistory his = new businesscontractreceivehistory();
                //        his.EteamsContractID = receive.EteamsContractID;
                //        his.ContractName = receive.ContractName;
                //        his.createtime = receive.updatetime;
                //        his.EteamsContractStageID = receive.EteamsContractStageID;
                //        his.StageName = receive.StageName;

                //        his.ReceiveTime = receive.ReceiveTime;
                //        his.ReceiveAmount = receive.ReceiveAmount;

                //        receivehistoryHelper.Add(his);



                //        Logger.Log("Receive SUCCESS:" + url);

                //    }
                //    catch (Exception ex)
                //    {

                //        receive.IsDelete = true;
                //        receive.updatetime = DateTime.Now;
                //        receiveHelper.Update(receive);




                //        var msg = "Receive Failure:" + url;
                //        Logger.Log(msg);

                //        stringBuilder.Append(msg);
                //        Logger.Log(ex);

                //    }


                //}
            }

            private void button5_Click(object sender, EventArgs e)
        {
          
        }

        private void button6_Click(object sender, EventArgs e)
        {
            DBHelper<businessemployee> businessemployeeHelper = new DBHelper<businessemployee>();

            DBHelper<poa_dept> deptHelper = new DBHelper<poa_dept>();

            var deptList = deptHelper.FindList(x => x.id > 0);


            DBHelper<poa_user> poa_userHelper = new DBHelper<poa_user>();


            businessemployeeHelper.RemoveList(x => x.Id > 0);

            var allList = poa_userHelper.FindList(x => x.type != "systemAccount");

            var empList = new List<businessemployee>();

            foreach(var emp in allList)
            {
                if(emp.status == "valid")
                {
                    DateTime begin = (DateTime)emp.entry_time;
                    while(begin< DateTime.Parse(DateTime.Now.ToString("yyyy-MM-dd")))
                    {
                       
                        businessemployee his = new businessemployee();
                        his.MonthID = Int32.Parse(begin.ToString("yyyyMM"));
                        his.DateID = Int32.Parse(begin.ToString("yyyyMMdd"));
                        his.UserCode = emp.user_code;
                        his.UserName = emp.name;
                        his.DeptName = deptList.First(x => x.dept_code == emp.dept_code).dept_full_name;
                        his.DeptCode = emp.dept_code;
                        his.LevelCoefficient = emp.level_coefficient;
                        his.CreateTime = DateTime.Now;
                        his.EmpType = emp.type;
                        businessemployeeHelper.Add(his);
                        begin = begin.AddDays(1);

                    }
                }
                else if (emp.status == "invalid")
                {
                    DateTime begin = (DateTime)emp.entry_time;
                    while (begin <= emp.quit_time)
                    {
                      
                        businessemployee his = new businessemployee();
                        his.MonthID = Int32.Parse(begin.ToString("yyyyMM"));
                        his.DateID = Int32.Parse(begin.ToString("yyyyMMdd"));
                        his.UserCode = emp.user_code;
                        his.UserName = emp.name;
                        his.DeptName = deptList.First(x => x.dept_code == emp.dept_code).dept_full_name;
                        his.DeptCode = emp.dept_code;
                        his.LevelCoefficient = emp.level_coefficient;
                        his.CreateTime = DateTime.Now;
                        his.EmpType = emp.type;
                        businessemployeeHelper.Add(his);
                        begin = begin.AddDays(1);

                    }
                }

            }
            
        }

        private void button7_Click(object sender, EventArgs e)
        {
            UpdateEmp();
        }

        private  void UpdateEmp()
        {
            try
            {
                DBHelper<businessemployee> businessemployeeHelper = new DBHelper<businessemployee>();

                DBHelper<poa_dept> deptHelper = new DBHelper<poa_dept>();

                var deptList = deptHelper.FindList(x => x.id > 0);


                DBHelper<poa_user> poa_userHelper = new DBHelper<poa_user>();


                int dateid = Int32.Parse(DateTime.Now.ToString("yyyyMMdd"));
                businessemployeeHelper.RemoveList(x => x.DateID == dateid); ;

                var allList = poa_userHelper.FindList(x =>  x.status == "valid"  && x.type != "systemAccount");

                var empList = new List<businessemployee>();

                foreach (var emp in allList)
                {

                    businessemployee his = new businessemployee();
                    his.MonthID = Int32.Parse(DateTime.Now.ToString("yyyyMM"));
                    his.DateID = Int32.Parse(DateTime.Now.ToString("yyyyMMdd"));
                    his.UserCode = emp.user_code;
                    his.UserName = emp.name;
                    his.DeptName = deptList.First(x => x.dept_code == emp.dept_code).dept_full_name;
                    his.DeptCode = emp.dept_code;
                    his.LevelCoefficient = emp.level_coefficient;
                    his.CreateTime = DateTime.Now;
                    his.EmpType = emp.type;
                    businessemployeeHelper.Add(his);


                }
            }
            catch(Exception e)
            {
                stringBuilder.Append("更新人员信息失败" + e.Message + e.StackTrace);
            }
            
        }

        private void button8_Click(object sender, EventArgs e)
        {
            UpdateProject();
        }

        private  void UpdateProject()
        {
            try
            {
                DBHelper<businessproject> businessprojecteHelper = new DBHelper<businessproject>();

                DBHelper<poa_project> poa_projectHelper = new DBHelper<poa_project>();




                int dateid = Int32.Parse(DateTime.Now.ToString("yyyyMMdd"));
                businessprojecteHelper.RemoveList(x => x.DateID == dateid);

                var allList = poa_projectHelper.FindList(x => x.stage != "商务关闭" && !(Boolean)x.is_deleted);



                foreach (var project in allList)
                {

                    businessproject his = new businessproject();
                    his.MonthId = Int32.Parse(DateTime.Now.ToString("yyyyMM"));
                    his.DateID = Int32.Parse(DateTime.Now.ToString("yyyyMMdd"));
                    his.ProjectCode = project.project_code;
                    his.ProjectName = project.project_name;
                    his.Stage = project.stage;
                    his.deliver_time = project.deliver_time;
                    his.BIZ_close_time = project.BIZ_close_time;
                    his.online_accep_time = project.online_accep_time;
                    his.progress_now = project.progress_now;
                    his.ModifyTime = project.modify_time;
                    businessprojecteHelper.Add(his);


                }
            }
            catch(Exception e)
            {
                stringBuilder.Append("更新项目信息失败" + e.Message + e.StackTrace);
            }
            
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if(autorun)
            {
                try
                {
                    Login();


                    GetChanceNew();


                    GetContractNew();
                    GetInvoice();

                    GetReceive();

                    CloseProcess();

                   

                }
                catch (Exception ex)
                {
                    stringBuilder.Append(ex.Message + ex.StackTrace);
                    Logger.Log(ex.Message + ex.StackTrace);
                }

                UpdateProject();

                UpdateEmp();


                EmailHelper.SendO365Email("framing.ni@yechtech.com", "", "framing.ni@yechtech.com", "", "Su8&#0ji", "营运数据同步", stringBuilder.ToString());

                this.Close();
            }

        }

        private void button9_Click(object sender, EventArgs e)
        {
            autorun = false;
        }
    }
}
