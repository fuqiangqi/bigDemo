package com.yechtech.eteams.spider.model;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.util.Date;

/**
 * businesscontractinvoice
 *
 * @author krx
 * @date 2022-07-13 14:04:18
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = false)
@TableName("businesscontractinvoice")
public class Businesscontractinvoice {
    @TableId(value = "id", type = IdType.AUTO)
    @JsonSerialize(using = ToStringSerializer.class)
    private Long id;
    private String eteamsinvocieid;
    private String eteamscontractid;
    private String contractname;
    private String eteamscontractstageid;
    private String invoicetype;
    private String stagename;
    private BigDecimal invoiceamount;
    private Date invoicetime;
    private Date createtime;
    private Date updatetime;
    private Boolean isdelete;
}
