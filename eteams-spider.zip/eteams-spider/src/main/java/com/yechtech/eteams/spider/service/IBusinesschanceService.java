package com.yechtech.eteams.spider.service;

import com.yechtech.eteams.spider.model.Businesschance;
import com.yechtech.common.model.PageResult;
import com.yechtech.common.service.ISuperService;
import com.yechtech.common.base.Result;

import java.util.Map;

/**
 * businesschance
 *
 * @author krx
 * @date 2022-07-13 14:04:16
 */
public interface IBusinesschanceService extends ISuperService<Businesschance> {


}

