package com.yechtech.eteams.spider.model;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;
import com.yechtech.common.base.SuperEntity;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Getter;
import lombok.Setter;
import lombok.EqualsAndHashCode;
        import java.math.BigDecimal;
    import java.util.Date;

/**
 * businessemployee
 *
 * @author krx
 * @date 2022-07-13 14:04:19
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = false)
@TableName("businessemployee")
public class Businessemployee  {
    @TableId(value = "id", type = IdType.AUTO)
    @JsonSerialize(using = ToStringSerializer.class)
    private Long id;
            private String usercode;
            private String username;
            private String deptcode;
            private String deptname;
            private BigDecimal levelcoefficient;
            private Integer dateid;
            private Integer monthid;
            private Date createtime;
            private String emptype;
    }
