package com.yechtech.eteams.spider.helper;

import cn.hutool.core.thread.ThreadUtil;
import cn.hutool.core.util.ObjectUtil;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class LoginHelper {

    public static WebDriver webDriver;

    public static void closeChromeDriver(WebDriver driver) {
        if (ObjectUtil.isNotEmpty(driver) || ObjectUtil.isNotNull(driver)) {
            try {
//                driver.close();
                driver.quit();
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else {
            try {
//                webDriver.close();
                webDriver.quit();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    //登录
    public static void login() {
        //设置驱动
        String userDir = System.getProperty("user.dir");
        System.setProperty("webdriver.chrome.driver", userDir + "\\chromedriver.exe");
        webDriver = new ChromeDriver();
        webDriver.navigate().to("https://passport.eteams.cn/login");
        checkLogin();
    }


    //校验登录
    public static void checkLogin() {
        //找到页面上的搜索框 输入关键字
        ThreadUtil.sleep(2000);
                    /*webDriver.findElement(By.xpath("//*[@id='root']/div/div[2]/div/div/div[4]/div[1]/input")).SendKeys("17717936101");
                 webDriver.findElement(By.xpath("//*[@id='root']/div/div[2]/div/div/div[4]/div[2]/input")).SendKeys("226697");*/
        webDriver.findElement(By.xpath("//*[@id='root']/div/div/div/div[2]/div/div/div/div/div[4]/div[1]/input")).sendKeys("17717936101");
        webDriver.findElement(By.xpath("//*[@id='root']/div/div/div/div[2]/div/div/div/div/div[4]/div[2]/input")).sendKeys("226697");
        ThreadUtil.sleep(5000);
        //点击搜索按钮
        webDriver.findElement(By.xpath("//*[@id='root']/div/div/div/div[2]/div/div/div/div/div[6]/button")).click();
        ThreadUtil.sleep(6000);
    }

    public static WebDriver getWebDriver() {
        login();
        return webDriver;
    }
}
