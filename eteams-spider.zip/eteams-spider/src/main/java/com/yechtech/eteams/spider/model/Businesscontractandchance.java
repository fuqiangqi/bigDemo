package com.yechtech.eteams.spider.model;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

import java.util.Date;

/**
 * businesscontractandchance
 *
 * @author krx
 * @date 2022-07-13 14:04:17
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = false)
@TableName("businesscontractandchance")
public class Businesscontractandchance {
    @TableId(value = "id", type = IdType.AUTO)
    @JsonSerialize(using = ToStringSerializer.class)
    private Long id;
    private String eteamscontractid;
    private String eteamschanceid;
    private Date createtime;
}
