package com.yechtech.eteams.spider.helper;

import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.WebDriver;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

@Component
@Slf4j
public class TaskHelper {


    WebDriver webDriver;

    StringBuilder stringBuilder = new StringBuilder();

    @Resource
    ChanceNewHelper chanceNewHelper;
    @Resource
    ContractNewHelper contractNewHelper;
    @Resource
    GetInvoiceHelper getInvoiceHelper;
    @Resource
    GetReceiveHelper getReceiveHelper;

    @Async
    public void task() {
        webDriver = LoginHelper.getWebDriver();
        //合同
        String sb1 = chanceNewHelper.execTaskChanceNew(webDriver);
        stringBuilder.append("chanceNewHelper").append(sb1);

        //新合同信息
        String sb2 = contractNewHelper.execTaskContractNew(webDriver);
        stringBuilder.append("contractNewHelper").append(sb2);

//        //发票
//        String sb3 = getInvoiceHelper.execTaskGetInvoice(webDriver);
//        stringBuilder.append("getInvoiceHelper").append(sb3);
//
//        //发票
//        String sb4 = getReceiveHelper.execTaskGetReceive(webDriver);
//        stringBuilder.append("getReceiveHelper").append(sb4);
        LoginHelper.closeChromeDriver(webDriver);
//        log.error("错误信息:{}", stringBuilder.toString());
    }
}
