package com.yechtech.eteams.spider.controller;

import com.yechtech.eteams.spider.helper.*;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

@RestController
@RequestMapping(value = "selenium/")
public class AppController {
    @Resource
    ChanceNewHelper chanceNewHelper;
    @Resource
    ContractNewHelper contractNewHelper;
    @Resource
    GetInvoiceHelper getInvoiceHelper;
    @Resource
    GetReceiveHelper getReceiveHelper;
    @Resource
    InitEmployeeHelper initEmployeeHelper;
    @Resource
    UpdateEmpHelper updateEmpHelper;
    @Resource
    UpdateProjectHelper updateProjectHelper;


    @GetMapping(value = "chanceNew")
    public void chanceNew(){
        chanceNewHelper.execChanceNew();
    }

    @GetMapping(value = "contractNew")
    public void contractNew(){
        contractNewHelper.execContractNew();
    }

    @GetMapping(value = "getInvoice")
    public void getInvoice(){
        getInvoiceHelper.execGetInvoice();
    }

    @GetMapping(value = "getReceive")
    public void getReceive(){
        getReceiveHelper.execGetReceive();
    }

    @GetMapping(value = "initEmp")
    public void initEmp(){
        initEmployeeHelper.execInitEmployee();
    }

    @GetMapping(value = "updateEmp")
    public void updateEmp(){
        updateEmpHelper.execUpdateEmp();
    }

    @GetMapping(value = "updatePro")
    public void updatePro(){
        updateProjectHelper.execUpdateProject();
    }
}
