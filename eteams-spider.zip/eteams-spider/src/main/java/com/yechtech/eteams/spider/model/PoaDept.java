package com.yechtech.eteams.spider.model;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * poa_dept
 *
 * @author krx
 * @date 2022-07-13 14:04:19
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = false)
@TableName("poa_dept")
public class PoaDept {
    @TableId(value = "id", type = IdType.AUTO)
    @JsonSerialize(using = ToStringSerializer.class)
    private Long id;
    private Integer deptPid;
    private Integer deptLevel;
    private String deptCode;
    private String deptSystemCode;
    private String deptFullName;
    private String deptShortName;
    private String deptNameEn;
    private Integer deptLeader;
    private Integer isPayDept;
    private Integer isIndexAnalysis;
    private Integer createUser;
    private Integer updateUser;
}
