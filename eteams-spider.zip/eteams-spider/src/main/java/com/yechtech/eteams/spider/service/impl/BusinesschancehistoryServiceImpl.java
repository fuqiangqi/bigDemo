package com.yechtech.eteams.spider.service.impl;

import org.springframework.stereotype.Service;
import com.yechtech.common.model.PageResult;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.yechtech.common.service.impl.SuperServiceImpl;
import com.yechtech.common.exceptions.BusinessException;
import com.yechtech.common.model.CommonErrCode;
import com.yechtech.common.utils.IdGenerator;
import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.util.ObjectUtil;
import com.yechtech.common.base.Result;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.apache.commons.collections4.MapUtils;
import lombok.extern.slf4j.Slf4j;

import com.yechtech.eteams.spider.model.Businesschancehistory;
import com.yechtech.eteams.spider.mapper.BusinesschancehistoryMapper;
import com.yechtech.eteams.spider.service.IBusinesschancehistoryService;

/**
 * businesschancehistory
 *
 * @author krx
 * @date 2022-07-13 14:04:17
 */
@Slf4j
@Service
public class BusinesschancehistoryServiceImpl extends SuperServiceImpl<BusinesschancehistoryMapper, Businesschancehistory> implements IBusinesschancehistoryService {

}
