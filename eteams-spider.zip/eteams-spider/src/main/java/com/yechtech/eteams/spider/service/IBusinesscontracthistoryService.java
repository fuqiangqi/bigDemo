package com.yechtech.eteams.spider.service;

import com.yechtech.eteams.spider.model.Businesscontracthistory;
import com.yechtech.common.model.PageResult;
import com.yechtech.common.service.ISuperService;
import com.yechtech.common.base.Result;

import java.util.Map;

/**
 * businesscontracthistory
 *
 * @author krx
 * @date 2022-07-13 15:21:50
 */
public interface IBusinesscontracthistoryService extends ISuperService<Businesscontracthistory> {

}

