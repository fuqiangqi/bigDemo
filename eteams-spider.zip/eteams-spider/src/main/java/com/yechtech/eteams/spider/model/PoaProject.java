package com.yechtech.eteams.spider.model;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.util.Date;

/**
 * poa_project
 *
 * @author krx
 * @date 2022-07-13 14:04:19
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = false)
@TableName("poa_project")
public class PoaProject {
    @TableId(value = "id", type = IdType.AUTO)
    @JsonSerialize(using = ToStringSerializer.class)
    private Long id;
    private String projectCode;
    private Integer projectCategory;
    private String projectName;
    private String stage;
    private Integer chargeUt;
    private Integer effectiveUt;
    private String signStatus;
    private Integer customerId;
    private String customerName;
    private Integer leaderId;
    private String leaderName;
    private Integer businessLeaderId;
    private String businessLeaderName;
    private Date deliverTime;
    private Date bizCloseTime;
    private Date onlineAccepTime;
    private Integer contractId;
    private String joinUsersJson;
    private BigDecimal progressNow;
    private Date appointCreateTime;
    private Date appointEndTime;
    private Date realCreateTime;
    private Date realEndTime;
    private BigDecimal totalManDays;
    private Integer consumption;
    private BigDecimal predictCost;
    private String otherCost;
    private String colorSign;
    private Integer modifyBy;
    private Date modifyTime;
    private Integer pid;
    private Integer projectLevel;
    private Integer isDeleted;
    private String projectSystemCode;
    private String remarks;
    private String fkEteamsid;
    private BigDecimal predictManday;
    private Integer predictBuffer;
    private BigDecimal projectAmount;
    private BigDecimal predictBufferManday;
    private BigDecimal predictMandayHour;
    private BigDecimal actualOwnCostRatio;
    private BigDecimal actualOwnCostAmount;
    private String projectType;
    private BigDecimal reserveRatio;
}
