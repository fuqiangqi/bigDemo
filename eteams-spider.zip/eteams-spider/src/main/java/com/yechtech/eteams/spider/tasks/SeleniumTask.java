package com.yechtech.eteams.spider.tasks;

import com.yechtech.eteams.spider.helper.*;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

@Configuration
public class SeleniumTask {

    @Resource
    TaskHelper taskHelper;


    @Scheduled(cron = "0 0 2 * * ?")
    public void task() {
        taskHelper.task();
    }
}
