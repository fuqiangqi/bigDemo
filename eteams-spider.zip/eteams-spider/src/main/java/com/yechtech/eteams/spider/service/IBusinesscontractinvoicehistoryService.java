package com.yechtech.eteams.spider.service;

import com.yechtech.eteams.spider.model.Businesscontractinvoicehistory;
import com.yechtech.common.model.PageResult;
import com.yechtech.common.service.ISuperService;
import com.yechtech.common.base.Result;

import java.util.Map;

/**
 * businesscontractinvoicehistory
 *
 * @author krx
 * @date 2022-07-13 16:05:21
 */
public interface IBusinesscontractinvoicehistoryService extends ISuperService<Businesscontractinvoicehistory> {


}

