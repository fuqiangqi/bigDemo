package com.yechtech.eteams.spider.model;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.util.Date;

/**
 * businesschancehistory
 *
 * @author krx
 * @date 2022-07-13 14:04:17
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = false)
@TableName("businesschancehistory")
public class Businesschancehistory {
    @TableId(value = "id", type = IdType.AUTO)
    @JsonSerialize(using = ToStringSerializer.class)
    private Long id;
    private String eteamsid;
    private String chancecode;
    private String chancename;
    private String managername;
    private BigDecimal money;
    private BigDecimal winrate;
    private String customername;
    private String chancetype;
    private String presales;
    private String dept;
    private Date prepotime;
    private Date actupotime;
    private Date invoicetime;
    private Boolean isdelete;
    private Date createtime;
    private String chancestage;
    private String category;
}
