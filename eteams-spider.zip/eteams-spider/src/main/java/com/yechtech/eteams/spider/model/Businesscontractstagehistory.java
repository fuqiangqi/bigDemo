package com.yechtech.eteams.spider.model;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.util.Date;

/**
 * businesscontractstagehistory
 *
 * @author krx
 * @date 2022-07-13 14:04:18
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = false)
@TableName("businesscontractstagehistory")
public class Businesscontractstagehistory {
    @TableId(value = "id", type = IdType.AUTO)
    @JsonSerialize(using = ToStringSerializer.class)
    private Long id;
    private String eteamscontractid;
    private String contractname;
    private String eteamscontractstageid;
    private String stagename;
    private BigDecimal stageamount;
    private String memo;
    private Date createtime;
    private Date targettime;
}
