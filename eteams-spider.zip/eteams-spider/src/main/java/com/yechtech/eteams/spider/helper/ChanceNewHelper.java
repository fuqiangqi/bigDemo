package com.yechtech.eteams.spider.helper;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.convert.Convert;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.exceptions.ExceptionUtil;
import cn.hutool.core.thread.ThreadUtil;
import com.baomidou.mybatisplus.core.toolkit.StringPool;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.yechtech.eteams.spider.model.Businesschance;
import com.yechtech.eteams.spider.model.Businesschancehistory;
import com.yechtech.eteams.spider.service.IBusinesschanceService;
import com.yechtech.eteams.spider.service.IBusinesschancehistoryService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.time.DateUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;

/**
 * 获取商机
 *
 * @auth krx
 * @date 2022/7/13 15:06
 */
@Component
@Slf4j
public class ChanceNewHelper {

    @Resource
    IBusinesschancehistoryService iBusinesschancehistoryService;
    @Resource
    IBusinesschanceService iBusinesschanceService;

    WebDriver webDriver;

    StringBuilder stringBuilder = new StringBuilder();


    //处理
    public void execChanceNew() {
        webDriver = LoginHelper.getWebDriver();
        getChanceNew();
        log.info("获取商机基本信息结束");
        LoginHelper.closeChromeDriver(webDriver);
    }


    //处理
    public String execTaskChanceNew(WebDriver driver) {
        webDriver = driver;
        getChanceNew();
        return stringBuilder.toString();
    }


    //获取商机内容
    private void getChanceNew() {
        //跳转到我的全部商机
        webDriver.navigate().to("https://weapp.eteams.cn/crm/salechance/9081908547940234461/list/all");
        //webDriver.findElement(By.xpath("//*[@id='mCSB_2_container']/ul/li[1]/ul/li[6]/a")).Click();
        ThreadUtil.sleep(6000);

        boolean autorun = true;
        if (autorun) {
            //点击包含赢单、输单和无效
            WebElement includesucess = webDriver.findElement(By.cssSelector(".ui-checkbox-left"));

            includesucess.click();
            ThreadUtil.sleep(3000);

            //获取总页数
            WebElement totalPageNode = webDriver.findElement(By.cssSelector(".ui-pagination-total.ui-pagination-placeholder"));
            if (!totalPageNode.isDisplayed()) {
                Actions action = new Actions(webDriver);
                action.moveToElement(totalPageNode);
                action.perform();
            }

            int totalNum = Convert.toInt(totalPageNode.getText().replace("共", "").replace("条", ""));
            List<WebElement> chancelist = webDriver.findElements(By.xpath("//*[@id=\"modulePanel\"]/div/div/div/div[1]/div[2]/div/div/div[2]/div/div/div/div/div[1]/table/tbody/tr"));

            boolean morePage = true;

            for (WebElement chance : chancelist) {
                String chanceid = chance.getAttribute("data-id");

                if (!chance.isDisplayed()) {
                    Actions action2 = new Actions(webDriver);
                    action2.moveToElement(chance);
                    action2.perform();
                    ThreadUtil.sleep(1000);
                }
                List<Businesschance> checkExit = iBusinesschanceService.list(Wrappers.<Businesschance>query().lambda().eq(Businesschance::getEteamsid, chanceid));
                if (checkExit.isEmpty()) {
                    Businesschance newbusinesschance = new Businesschance();
                    newbusinesschance.setEteamsid(chanceid);
                    WebElement createtimeNode = chance.findElements(By.tagName("td")).get(10);
                    newbusinesschance.setCreatetime(DateUtil.parse(createtimeNode.getText(), "yyyy-MM-dd"));
                    WebElement updateNode = chance.findElements(By.tagName("td")).get(5);
                    newbusinesschance.setUpdatetime(DateUtil.parse(updateNode.getText(), "yyyy-MM-dd"));
                    iBusinesschanceService.save(newbusinesschance);
                } else {
                    checkExit.get(0).setEteamsid(chanceid);
                    WebElement createtimeNode = chance.findElements(By.tagName("td")).get(10);
                    checkExit.get(0).setCreatetime(DateUtil.parse(createtimeNode.getText(), "yyyy-MM-dd"));
                    WebElement updateNode = chance.findElements(By.tagName("td")).get(5);
                    checkExit.get(0).setUpdatetime(DateUtil.parse(updateNode.getText(), "yyyy-MM-dd"));
                    iBusinesschanceService.saveOrUpdate(checkExit.get(0));
                }
            }


            //获取点击下一页的次数
            int clickNextTime = totalNum / 30;


            for (int i = 0; i <= clickNextTime; i++) {
                if (!morePage) {
                    break;
                }
                WebElement nextNode = webDriver.findElement(By.cssSelector(".ui-icon-xs.ui-icon-svg.Icon-Right-arrow01"));
                nextNode.click();
                ThreadUtil.sleep(1000);

                chancelist = webDriver.findElements(By.xpath("//*[@id=\"modulePanel\"]/div/div/div/div[1]/div[2]/div/div/div[2]/div/div/div/div/div[1]/table/tbody/tr"));
                ThreadUtil.sleep(3000);

                int index = 0;
                for (WebElement chance : chancelist) {
                    try {
                        String chanceid = chance.getAttribute("data-id");
                        index++;
                        if (!chance.isDisplayed()) {
                            Actions action2 = new Actions(webDriver);
                            action2.moveToElement(chance);
                            action2.perform();
                            ThreadUtil.sleep(1000);
                        }

                        List<Businesschance> checkExit = iBusinesschanceService.list(Wrappers.<Businesschance>query().lambda().eq(Businesschance::getEteamsid, chanceid));
                        if (checkExit.isEmpty()) {
                            Businesschance newbusinesschance = new Businesschance();
                            newbusinesschance.setEteamsid(chanceid);
                            WebElement createtimeNode = chance.findElements(By.tagName("td")).get(10);
                            newbusinesschance.setCreatetime(DateUtil.parse(createtimeNode.getText(), "yyyy-MM-dd"));
                            WebElement updateNode = chance.findElements(By.tagName("td")).get(5);
                            newbusinesschance.setUpdatetime(DateUtil.parse(updateNode.getText(), "yyyy-MM-dd"));
                            iBusinesschanceService.save(newbusinesschance);
                        } else {
                            checkExit.get(0).setEteamsid(chanceid);
                            WebElement createtimeNode = chance.findElements(By.tagName("td")).get(10);
                            checkExit.get(0).setCreatetime(DateUtil.parse(createtimeNode.getText(), "yyyy-MM-dd"));
                            WebElement updateNode = chance.findElements(By.tagName("td")).get(5);
                            checkExit.get(0).setUpdatetime(DateUtil.parse(updateNode.getText(), "yyyy-MM-dd"));
                            iBusinesschanceService.saveOrUpdate(checkExit.get(0));
                        }
                    } catch (Exception d) {
                        log.error("更新数据库失败:{}", ExceptionUtil.stacktraceToString(d));
                    }

                }
            }

        }


        //开始打开页面遍历商机内容
        ////负责人js_managerName
        //chanceUrlList.Add("https://www.eteams.cn/crms/saleChance?menu=key_all|state_0|module_saleChance|targetId_406&search=view_|searchId_406&table=view_&info=view_SaleChanceView|saleChanceId_4732608807705504048&tab=type_");
        //chanceUrlList.Add("https://www.eteams.cn/crms/saleChance?menu=key_all|state_0|module_saleChance|targetId_406&search=view_|searchId_406&table=view_&info=view_SaleChanceView|saleChanceId_8472683743121686769&tab=type_");
        //var comparedate = DateTime.Parse(DateTime.Now.AddDays(-1).ToString("yyyy-MM-dd"));
        List<Businesschance> etramList = iBusinesschanceService.list(Wrappers.<Businesschance>query().lambda().gt(Businesschance::getId, 0).orderByDesc(Businesschance::getId));
        if (etramList.isEmpty()) {
            log.info("没有查询到内容");
        } else {
            log.info("index-1"+etramList.get(0).getEteamsid());
        }
        for (Businesschance eteamsChance : etramList) {
//            if (!eteamsChance.getEteamsid().equals("8472683743126186802")) {
//                continue;
//            }
            log.info("startindex"+eteamsChance.getEteamsid());

            String url = String.format("https://weapp.eteams.cn/crm/salechance/9081908547940234461/list/all/detail/%s", eteamsChance.getEteamsid());
            log.info("开始更新地址start" + url);
            webDriver.navigate().to(url);
            ThreadUtil.sleep(10000);

            try {
                GetChanceDeatil(eteamsChance, url);
            } catch (Exception ex) {
                try {
                    log.info("重刷界面");
                    webDriver.navigate().refresh();
                    ThreadUtil.sleep(10000);
                    GetChanceDeatil(eteamsChance, url);
                } catch (Exception ex2) {
                    String msg = "Get Chance Failure:" + url;
                    log.info(msg);
                    stringBuilder.append(msg);
                    log.info(ExceptionUtil.stacktraceToOneLineString(ex2));
                }


            }
            log.info("更新地址结束end" + url);
            log.info("endindex"+eteamsChance.getEteamsid());
        }
    }

    //获取商机详情
    private void GetChanceDeatil(Businesschance eteamsChance, String url) {
        boolean isDelete = false;
//        try {
//            //判断是不是被作废和逻辑删除
//            String displaytext = webDriver.findElement(By.xpath("//*[@id=\"ui-dialog-header-draggable\"]/div/div[1]/div/div[2]/div[1]/div/span[2]")).getText();
//            if (displaytext.equals("此商机已被移到回收站")) {
//                isDelete = true;
//            }
//
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//
//        if (!isDelete) {
//            try {
//                //判断是不是被作废和逻辑删除
//                WebElement chanceNode = webDriver.findElement(By.id("js_loadding"));
//                if (chanceNode.isDisplayed()) {
//                    isDelete = true;
//                }
//
//            } catch (Exception e) {
//                e.printStackTrace();
//            }
//        }


        if (!isDelete) {
            log.info("开始获取详情商机详情");
            //*[@id="dialog_tj2xi4"]
            String dialogid = webDriver.findElement(By.cssSelector(".ui-dialog-wrap.ui-dialog-wrap-right.ui-dialog-content-scale")).getAttribute("id");

            log.info("dialogid" + dialogid);

            String chanceCode = webDriver.findElement(By.xpath("//*[@id=\"widget_2182165012281802449\"]/div[2]/div[2]/label")).getText();

            log.info("chanceCode" + chanceCode);
            String chancename = webDriver.findElement(By.xpath("//*[@id=\"" + dialogid + "\"]/div[2]/div/div/div/div[2]/div/div/div/div/div/div/div/div[2]/div[1]/div[1]/div[2]/input")).getAttribute("value");
            log.info("chancename" + chancename);
            String managerName = webDriver.findElement(By.xpath("//*[@id=\"" + dialogid + "\"]/div[2]/div/div/div/div[2]/div/div/div/div/div/div/div/div[2]/div[2]/div/div[1]/div/div[2]/div/div/div/div/div/div/div/div/div/div/div/div/div/span")).getText();
            log.info("managerName" + managerName);
            //销售金额
            String money = webDriver.findElement(By.id("money")).getAttribute("value");
            log.info("money" + money);
            //商机阶段
            String chancestage = webDriver.findElement(By.xpath("//*[@id=\"" + dialogid + "\"]/div[2]/div/div/div/div[2]/div/div/div/div/div/div/div/div[2]/div[2]/div/div[2]/div/div[2]/div/div/div/span/div/div/div/span[1]/div/div/div/div/div/div/div/div/div/div/div/span")).getText();
            log.info("chancestage" + chancestage);
            //商机赢率
            String winrate = webDriver.findElement(By.xpath("//*[@id=\"" + dialogid + "\"]/div[2]/div/div/div/div[2]/div/div/div/div/div/div/div/div[2]/div[3]/div[1]/div[2]/div/div[2]/div/div/div/div/div/span[1]")).getText().replace("%", "").replace("请选择", "");
            log.info("winrate" + winrate);
            //所属客户
            String customerName = webDriver.findElement(By.xpath("//*[@id=\"" + dialogid + "\"]/div[2]/div/div/div/div[2]/div/div/div/div/div/div/div/div[2]/div[3]/div[3]/div[1]/div/div[2]/div/div/div/span/div/div/div/span[1]/div/div/div/div/div/div/div/div/div/div/div/span")).getText();
            log.info("customerName" + customerName);
            //商机类型
            String chanceType = webDriver.findElement(By.xpath("//*[@id=\"" + dialogid + "\"]/div[2]/div/div/div/div[2]/div/div/div/div/div/div/div/div[2]/div[3]/div[2]/div[2]/div/div[2]/div/div/div/span/div/div/div/span[1]/div/div/div/div/div/div/div/div/div/div/div/span")).getText();
            log.info("chanceType" + chanceType);
            //商机大类
            String category = webDriver.findElement(By.xpath("//*[@id=\"widget_4743193737385227535\"]/div[2]/div[2]/div/div/div/span[1]")).getText();
            log.info("category" + category);

            //售前负责人
            String presales = StringPool.EMPTY;
            try {
                presales = webDriver.findElement(By.xpath("//*[@id=\"widget_1473472292671572782\"]/div[2]/div[2]/div/div/div/span[1]")).getText();
                log.info("presales" + presales);
            } catch (Exception e) {
                e.printStackTrace();
                log.error("售前负责人为空" + url);
            }

            //部门
            String dept = webDriver.findElement(By.xpath("//*[@id=\"widget_4742641986291346223\"]/div[2]/div[2]/div/div/div/span[1]")).getText();
            log.info("dept" + dept);

            //预计PO时间
            String prepotime = webDriver.findElement(By.xpath("//*[@id=\"widget_7963030243256199806\"]/div[2]/div[2]/div/div/div/input")).getAttribute("value");
            log.info("prepotime" + prepotime);
            //实际PO时间
            String actupotime = webDriver.findElement(By.xpath("//*[@id=\"widget_7962911296615139707\"]/div[2]/div[2]/div/div/div/input")).getAttribute("value");
            log.info("actupotime" + actupotime);
            //预计开票时间
            String invoicetime = webDriver.findElement(By.xpath("//*[@id=\"widget_7962911296615139705\"]/div[2]/div[2]/div/div/div/input")).getAttribute("value");
            log.info("invoicetime" + invoicetime);


            //判断先前是否同步到本地
            eteamsChance.setChancename(chancename);
            eteamsChance.setChancecode(chanceCode);
            eteamsChance.setChancestage(chancestage);
            eteamsChance.setManagername(managerName);
            eteamsChance.setMoney(StringUtils.hasLength(money) && StringUtils.hasText(money) ? Convert.toBigDecimal(money) : null);
            eteamsChance.setWinrate(StringUtils.hasLength(winrate) && StringUtils.hasText(winrate) ? Convert.toBigDecimal(winrate) : null);

            eteamsChance.setCustomername(customerName);
            eteamsChance.setChancetype(chanceType);
            eteamsChance.setPresales(presales);
            eteamsChance.setDept(dept);

            eteamsChance.setPrepotime(StringUtils.hasLength(prepotime) && StringUtils.hasText(prepotime) ? DateUtil.parse(prepotime, "yyyy-MM-dd") : null);
            eteamsChance.setActupotime(StringUtils.hasLength(actupotime) && StringUtils.hasText(actupotime) ? DateUtil.parse(actupotime, "yyyy-MM-dd") : null);
            eteamsChance.setInvoicetime(StringUtils.hasLength(invoicetime) && StringUtils.hasText(invoicetime) ? DateUtil.parse(invoicetime, "yyyy-MM-dd") : null);

            eteamsChance.setCategory(category);
            eteamsChance.setUpdatetime(new Date());
        } else {
            eteamsChance.setIsdelete(isDelete);
        }
        iBusinesschanceService.saveOrUpdate(eteamsChance);

        Businesschancehistory businesschancehistory = BeanUtil.copyProperties(eteamsChance, Businesschancehistory.class);
        businesschancehistory.setId(null);
        businesschancehistory.setCreatetime(new Date());
        iBusinesschancehistoryService.save(businesschancehistory);
        log.info("SUCCESS:" + url);
    }
}
