package com.yechtech.eteams.spider;

import com.baomidou.mybatisplus.core.toolkit.StringPool;
import lombok.extern.slf4j.Slf4j;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.core.env.Environment;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;

import java.net.InetAddress;
import java.net.UnknownHostException;

@Slf4j
@SpringBootApplication(scanBasePackages = {"com.yechtech", "com.yechtech.eteams.spider"})
@MapperScan(basePackages = {"com.yechtech.eteams.spider.mapper*"})
@EnableScheduling
@EnableAsync
public class AppStartApplication implements CommandLineRunner {
    public static void main(String[] args) throws UnknownHostException {
        ConfigurableApplicationContext configurableApplicationContext = SpringApplication.run(AppStartApplication.class, args);
        Environment env = configurableApplicationContext.getEnvironment();
        String ip = InetAddress.getLocalHost().getHostAddress();
        String port = env.getProperty("server.port");
        String path = env.getProperty("server.servlet.context-path");
        path = StringPool.SLASH.equals(path) ? "" : path;
        log.info("\n-------------------------------------------------------------------------------------------\n\t" +
                "Access URLs:\n\t" +
                "Local: \t\thttp://localhost:" + port + path + "\n\t" +
                "External: \thttp://" + ip + ":" + port + path + "\n\t" +
                "-------------------------------------------------------------------------------------------");
        System.setProperty("druid.mysql.usePingMethod", "false");
    }

    @Override
    public void run(String... args) {
        log.info("App started!");
    }
}