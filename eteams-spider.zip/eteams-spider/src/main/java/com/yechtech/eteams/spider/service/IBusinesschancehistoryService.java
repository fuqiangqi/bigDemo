package com.yechtech.eteams.spider.service;

import com.yechtech.eteams.spider.model.Businesschancehistory;
import com.yechtech.common.model.PageResult;
import com.yechtech.common.service.ISuperService;
import com.yechtech.common.base.Result;

import java.util.Map;

/**
 * businesschancehistory
 *
 * @author krx
 * @date 2022-07-13 14:04:17
 */
public interface IBusinesschancehistoryService extends ISuperService<Businesschancehistory> {

}

