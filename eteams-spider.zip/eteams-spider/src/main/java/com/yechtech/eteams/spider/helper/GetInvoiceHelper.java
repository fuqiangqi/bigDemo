package com.yechtech.eteams.spider.helper;

import cn.hutool.core.convert.Convert;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.thread.ThreadUtil;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.yechtech.eteams.spider.model.Businesscontract;
import com.yechtech.eteams.spider.model.Businesscontractinvoice;
import com.yechtech.eteams.spider.service.IBusinesscontractService;
import com.yechtech.eteams.spider.service.IBusinesscontractinvoiceService;
import com.yechtech.eteams.spider.service.IBusinesscontractinvoicehistoryService;
import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;

/**
 * 发票
 *
 * @auth krx
 * @date 2022/7/13 16:00
 */
@Component
@Slf4j
public class GetInvoiceHelper {

    @Resource
    IBusinesscontractinvoiceService businesscontractinvoiceService;
    @Resource
    IBusinesscontractService businesscontractService;
    @Resource
    IBusinesscontractinvoicehistoryService businesscontractinvoicehistoryService;

    WebDriver webDriver;



    public void execGetInvoice() {
        webDriver = LoginHelper.getWebDriver();
        GetInvoice();
        LoginHelper.closeChromeDriver(webDriver);
    }

    public String execTaskGetInvoice(WebDriver driver) {
        webDriver = driver;
        GetInvoice();
        return null;
    }


    private void GetInvoice() {
        //跳转开票
        webDriver.navigate().to("https://weapp.eteams.cn/crm/contract/9081908547940234461/ledger/list/invoice");
        //webDriver.findElement(By.xpath("//*[@id='mCSB_2_container']/ul/li[1]/ul/li[6]/a")).Click();

        ThreadUtil.sleep(5000);

        //获取总页数

        WebElement totalPageNode = webDriver.findElement(By.cssSelector(".ui-pagination-total.ui-pagination-placeholder"));
        if (!totalPageNode.isDisplayed()) {
            Actions action = new Actions(webDriver);
            action.moveToElement(totalPageNode);
            action.perform();
        }

        int totalNum = Convert.toInt(totalPageNode.getText().replace("共", "").replace("条", ""));


        //在最后一页中获取最新的记录插入数据库
        //
        List<WebElement> invoicelist = webDriver.findElements(By.xpath("//*[@id=\"modulePanel\"]/div/div/div/div/div[2]/div/div/div[3]/div/div/div[1]/table/tbody/tr"));

        for (WebElement invoice : invoicelist) {
            String invoiceId = invoice.getAttribute("data-id");
            List<WebElement> tds = invoice.findElements(By.tagName("td"));

            List<Businesscontractinvoice> checkExit = businesscontractinvoiceService.list(Wrappers.<Businesscontractinvoice>query().lambda().eq(Businesscontractinvoice::getEteamsinvocieid, invoiceId));
            String contractname = tds.get(1).getText().trim().replace(" ", "");
            String etreamContractId = "";
            List<Businesscontract> contractList = businesscontractService.list(Wrappers.<Businesscontract>query().lambda().eq(Businesscontract::getContractname, contractname));
            if (contractList.size() == 1) {
                etreamContractId = contractList.get(0).getEteamscontractid();
            }

            if (checkExit.size() == 0) {
                Businesscontractinvoice newbusinesscontractinvoice = new Businesscontractinvoice();
                newbusinesscontractinvoice.setEteamsinvocieid(invoiceId);
                newbusinesscontractinvoice.setInvoiceamount(Convert.toBigDecimal(tds.get(3).getText().replace(",", "")));
                newbusinesscontractinvoice.setInvoicetime(DateUtil.parseTime(tds.get(4).getText()));
                newbusinesscontractinvoice.setContractname(tds.get(1).getText().trim().replace(" ", ""));
                newbusinesscontractinvoice.setEteamscontractid(etreamContractId);
                newbusinesscontractinvoice.setStagename(tds.get(2).getText().trim());
                newbusinesscontractinvoice.setCreatetime(DateUtil.date());
                newbusinesscontractinvoice.setUpdatetime(DateUtil.date());
                businesscontractinvoiceService.save(newbusinesscontractinvoice);
            } else {
                checkExit.get(0).setInvoiceamount(Convert.toBigDecimal(tds.get(3).getText().replace(",", "")));
                checkExit.get(0).setInvoicetime(DateUtil.parseTime(tds.get(4).getText()));
                checkExit.get(0).setContractname(tds.get(1).getText().trim().replace(" ", ""));
                checkExit.get(0).setEteamscontractid(etreamContractId);
                checkExit.get(0).setStagename(tds.get(2).getText().trim());
                checkExit.get(0).setUpdatetime(DateUtil.date());
                businesscontractinvoiceService.updateById(checkExit.get(0));
            }

        }

        //获取点击下一页的次数
        int clickNextTime = totalNum / 30;

        for (int i = 0; i <= clickNextTime; i++) {
            WebElement nextNode = webDriver.findElement(By.cssSelector(".ui-pagination-pager-item.ui-pagination-pager-next"));
            if (!nextNode.isDisplayed()) {
                Actions action = new Actions(webDriver);
                action.moveToElement(nextNode);
                nextNode.click();
                action.perform();
            }

            JavascriptExecutor javaScriptExecutor = (JavascriptExecutor) webDriver;
            javaScriptExecutor.executeScript("arguments[0].click();", nextNode);

            ThreadUtil.sleep(2000);


            invoicelist = webDriver.findElements(By.xpath("//*[@id=\"modulePanel\"]/div/div/div/div/div[2]/div/div/div[3]/div/div/div[1]/table/tbody/tr"));

            for (WebElement invoice : invoicelist) {
                String invoiceId = invoice.getAttribute("data-id");

                List<WebElement> tds = invoice.findElements(By.tagName("td"));


                List<Businesscontractinvoice> checkExit = businesscontractinvoiceService.list(Wrappers.<Businesscontractinvoice>query().lambda().eq(Businesscontractinvoice::getEteamsinvocieid, invoiceId));
                String contractname = tds.get(1).getText().trim().replace(" ", "");
                String etreamContractId = "";
                List<Businesscontract> contractList = businesscontractService.list(Wrappers.<Businesscontract>query().lambda().eq(Businesscontract::getContractname, contractname));
                if (contractList.size() == 1) {
                    etreamContractId = contractList.get(0).getEteamscontractid();
                }
                if (checkExit.size() == 0) {
                    Businesscontractinvoice newbusinesscontractinvoice = new Businesscontractinvoice();
                    newbusinesscontractinvoice.setEteamsinvocieid(invoiceId);
                    newbusinesscontractinvoice.setInvoiceamount(Convert.toBigDecimal(tds.get(3).getText().replace(",", "")));
                    newbusinesscontractinvoice.setInvoicetime(DateUtil.parseTime(tds.get(4).getText()));
                    newbusinesscontractinvoice.setContractname(tds.get(1).getText().trim().replace(" ", ""));
                    newbusinesscontractinvoice.setEteamscontractid(etreamContractId);
                    newbusinesscontractinvoice.setStagename(tds.get(2).getText().trim());
                    newbusinesscontractinvoice.setCreatetime(DateUtil.date());
                    newbusinesscontractinvoice.setUpdatetime(DateUtil.date());
                    businesscontractinvoiceService.save(newbusinesscontractinvoice);
                } else {
                    checkExit.get(0).setInvoiceamount(Convert.toBigDecimal(tds.get(3).getText().replace(",", "")));
                    checkExit.get(0).setInvoicetime(DateUtil.parseTime(tds.get(4).getText()));
                    checkExit.get(0).setContractname(tds.get(1).getText().trim().replace(" ", ""));
                    checkExit.get(0).setEteamscontractid(etreamContractId);
                    checkExit.get(0).setStagename(tds.get(2).getText().trim());
                    checkExit.get(0).setUpdatetime(DateUtil.date());
                    businesscontractinvoiceService.updateById(checkExit.get(0));
                }

            }

        }


        //var allInvoiceList = businesscontractinvoiceHelper.FindList(x => x.Id > 0).OrderByDescending(x =>x.Id);


        // foreach (var invoice in allInvoiceList)
        // {
        //     var url = string.Format("https://www.eteams.cn/crms/contractLedgerSetting?menu=key_contractInvoiceLedger|state_0|module_contract|targetId_&search=view_&table=view_&info=view_ContractInvoiceView|invoiceId_{0}&tab=type_contractInvoiceLedger", invoice.EteamsInvocieID);

        //     // url = "https://www.eteams.cn/crms/contract?menu=key_all|state_0|module_contract|targetId_506&search=view_&table=view_&info=view_ContractView|contractId_8472303386626503805&tab=type_";
        //     try
        //     {

        //         webDriver.Navigate().GoToUrl(url);

        //         ThreadUtil.sleep(3000);


        //         var contractNode = webDriver.findElement(By.cssSelector(".entity-item.js_contractName.j_showContract")).findElement(By.tagName("a"));
        //         var contractName = contractNode.getText();
        //         var contractID = contractNode.getAttribute("data-id");


        //         var stageNode = webDriver.findElement(By.cssSelector(".entity-item.js_contractStageName")).findElement(By.tagName("a"));
        //         var stageName = stageNode.getText();
        //         var stageID = stageNode.getAttribute("data-id");


        //         var invoiceType = webDriver.findElement(By.Id("contractInvoice-type")).getText();//

        //         var invoiceAmount = webDriver.findElement(By.cssSelector(".form-control.js_field.js_invoice_money.textinput.contract-invoicemoney-input")).getAttribute("value");//

        //         var invoiceTime = webDriver.findElement(By.Id("invoiceTime")).getAttribute("value");//


        //         invoice.ContractName = contractName;
        //         invoice.EteamsContractID = contractID;

        //         invoice.EteamsContractStageID = stageID;
        //         invoice.StageName = stageName;

        //         invoice.InvoiceType = invoiceType;

        //         if (!string.IsNullOrEmpty(invoiceAmount))
        //         {
        //             invoice.InvoiceAmount = Decimal.Parse(invoiceAmount);
        //         }


        //         if (!string.IsNullOrEmpty(invoiceTime))
        //         {
        //             invoice.InvoiceTime = DateTime.Parse(invoiceTime);
        //         }

        //         invoice.updatetime = DateTime.Now;

        //         businesscontractinvoiceHelper.Update(invoice);

        //         businesscontractinvoicehistory his = new businesscontractinvoicehistory();
        //         his.EteamsContractID = invoice.EteamsContractID;
        //         his.ContractName = invoice.ContractName;
        //         his.createtime = invoice.updatetime;
        //         his.EteamsContractStageID = invoice.EteamsContractStageID;
        //         his.StageName = invoice.StageName;
        //         his.InvoiceType = invoice.InvoiceType;
        //         his.InvoiceAmount = invoice.InvoiceAmount;
        //         his.InvoiceTime = invoice.InvoiceTime;

        //         businesscontractinvoicehistoryHelper.Add(his);


        //         Logger.Log("INVOICE SUCCESS:" + url);

        //     }
        //     catch (Exception ex)
        //     {
        //         invoice.updatetime = DateTime.Now;
        //         invoice.IsDelete = true;
        //         businesscontractinvoiceHelper.Update(invoice);

        //         var msg = "INVOICE Failure:" + url;
        //         Logger.Log(msg);
        //         stringBuilder.Append(msg);
        //         Logger.Log(ex);

        //     }


        // }
    }
}
