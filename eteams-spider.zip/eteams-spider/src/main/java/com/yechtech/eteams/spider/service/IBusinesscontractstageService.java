package com.yechtech.eteams.spider.service;

import com.yechtech.eteams.spider.model.Businesscontractstage;
import com.yechtech.common.model.PageResult;
import com.yechtech.common.service.ISuperService;
import com.yechtech.common.base.Result;

import java.util.Map;

/**
 * businesscontractstage
 *
 * @author krx
 * @date 2022-07-13 14:04:17
 */
public interface IBusinesscontractstageService extends ISuperService<Businesscontractstage> {

    void del(String eteamscontractid);
}

